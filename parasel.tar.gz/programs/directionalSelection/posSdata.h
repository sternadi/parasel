#ifndef __POS_DATA
#define __POS_DATA

#include "definitions.h"
#include "alphabet.h"
#include "nodeData.h"

#include <iostream>

class posData;
class posData {
public:
	posData(int pos_in_MSA, int pos_in_RefSeq,int refSeqContent);
	~posData() {};
	void addPosteriorProb(MDOUBLE posteriorProb);
	void addML_S(MDOUBLE S) {_ML_S=S;}

	void clearPosteriorProbs();
	int getPosInMSA() const {return _pos_in_MSA;}
	int getPosInRefSeq() const {return _pos_in_RefSeq;}
	int getRefSeqContent() const {return _refSeqContent;}
	void printPostVal(ostream &out, const alphabet* alph);

	bool isDirectionalSelection (MDOUBLE cutoff);

private:
	int _pos_in_MSA;
	int _pos_in_RefSeq;
	int _refSeqContent;
	Vdouble _posteriorProbs; // for each spVec category
	MDOUBLE _ML_S; // ML S value if posterior > threshold

};

#endif // __POS_DATA
