#ifndef MUTATION_MAPPING_4SITE
#define MUTATION_MAPPING_4SITE

#include "tree.h"
#include "sequenceContainer.h"
#include "stochasticProcess.h"
#include "distribution.h"
#include "suffStatComponent.h"
#include "computeUpAlg.h"
#include "computeDownAlg.h"
#include "treeIt.h"
#include "likelihoodComputationSPvec.h"
#include "posSdata.h"
#include "nodeData.h"

class mutationMapping4site
{
public:
	mutationMapping4site(const tree& et,
		const sequenceContainer& sc,
		const vector <stochasticProcess*>& spVec,
		const distribution* spVecDistr, const sequence &refseq, bool rootKnown, suffStatGlobalGamSpVec * sscUpAllPos);
	~mutationMapping4site() {}
	void computeSignificantBranches(vector<posData>& positionsData,MDOUBLE cutoff,computePijGamSpVec& pij,  VVVdouble &initFreqs, ostream &out);
	void printSeqTrajectories(MDOUBLE threshold,ostream &out);

private:
	void init();
	doubleRep calcJointProbGivenSpAndRate(int node_id, int spVecCategor, int rateCategor, computePijHom& pijGivenSpAndRate,int letter, int fatherLetter, MDOUBLE initFreq) const;
	void calcPosUpAndDown(const posData& positionData,computePijGamSpVec& pij, VVdouble &initFreqs);

private:
	const tree& _et;
	const sequenceContainer& _sc;
	vector <stochasticProcess*> _spVec;
	const distribution* _spVecDistr;
	sequence _refSeq;
	bool _rootKnown; /// do we know state at root? i.e., is stationary distribution at root or not

	suffStatGlobalGamSpVec *_sscUpAllPos;
	suffStatGlobalGamSpVecPos _cup;
	suffStatGlobalGamSpVecPos _cdown;

	vector<nodeData> _nodesData;

};

#endif // MUTATION_MAPPING_4SITE
