#include "mutationMapping4site.h"
#include "matrixUtils.h"
#include "likelihoodComputationSPvecNonStationary.h"
#include "treeUtil.h"
//#include "simulateRateShiftJumps.h"

mutationMapping4site::mutationMapping4site(const tree& et,
		const sequenceContainer& sc,
		const vector <stochasticProcess*>& spVec,
		const distribution* spVecDistr, const sequence &refseq, bool rootKnown, suffStatGlobalGamSpVec * sscUpAllPos /*= NULL*/):
_et(et),
_sc(sc),
_spVec(spVec),
_spVecDistr(spVecDistr),
_refSeq(refseq),
_rootKnown(rootKnown),
_sscUpAllPos(NULL)
{
	if (sscUpAllPos)
		_sscUpAllPos = sscUpAllPos;
	init();
}

void mutationMapping4site::init()
{


	_cup.allocatePlace(_spVec.size(),_spVec[0]->categories(), _et.getNodesNum(), _sc.alphabetSize());
	_cdown.allocatePlace(_spVec.size(),_spVec[0]->categories(), _et.getNodesNum(), _sc.alphabetSize());

}


void mutationMapping4site::computeSignificantBranches(vector<posData>& positionsData,MDOUBLE cutoff,
												 computePijGamSpVec& pij,  VVVdouble &initFreqs, ostream &out)
{



	MDOUBLE epsilon = 0.001;

	treeIterDownTopConst tIt(_et);
	int letter,fatherLetter;

	vector<posData>::iterator positionsDataItr;
	int alphSize = _sc.alphabetSize();
	out<<"#Pos(query)\tnode_id\tnode_name\t_dis2root\tletter1\tletter2\tprob"<<endl;
	for (positionsDataItr=positionsData.begin(); positionsDataItr != positionsData.end(); ++positionsDataItr) { 
//		if (!positionsDataItr->isDirectionalSelection(cutoff))
//			continue;
		if (positionsDataItr->getPosInRefSeq() < 0) // we seek for branches of the refSeq significant positions only
			continue;
		int pos_in_MSA = positionsDataItr->getPosInMSA();
		cout<<".."<<pos_in_MSA;
		calcPosUpAndDown(*positionsDataItr,pij, initFreqs[pos_in_MSA]);

		doubleRep likelihoodPos(0.0);
		VVVdoubleRep mutationProbs(_et.getNodesNum()); // mutations probs per current site
		for (int i=0; i< mutationProbs.size(); ++i)
			resizeMatrix(mutationProbs[i],alphSize,alphSize);
		for (int spVecCategor=0; spVecCategor < _spVec.size(); ++spVecCategor) {
			doubleRep likelihoodPosGivenSp(0.0);
			for (int rateCategor=0; rateCategor < _spVec[0]->categories(); ++rateCategor) {
				doubleRep likelihoodPosGivenSpGivenRate(0.0);
				for(letter=0; letter<alphSize;++letter) {
					for (tree::nodeP mynode = tIt.first(); mynode != tIt.end(); mynode = tIt.next()) {

						if (mynode->isRoot() == false)	{
							for (fatherLetter=0; fatherLetter<alphSize;++fatherLetter) {
								MDOUBLE pi = (_rootKnown?1.0:initFreqs[pos_in_MSA][spVecCategor][fatherLetter]);

								MDOUBLE v=calcJointProbGivenSpAndRate(mynode->id(),spVecCategor,rateCategor,pij[spVecCategor][rateCategor],
										letter,fatherLetter, pi);
								mutationProbs[mynode->id()][letter][fatherLetter]+=v;
							}
						}
						else { // root
							likelihoodPosGivenSpGivenRate+=_cup.get(spVecCategor,rateCategor, mynode->id(),letter) * initFreqs[pos_in_MSA][spVecCategor][letter];
						}
					}
				}
				likelihoodPosGivenSpGivenRate*=_spVec[0]->ratesProb(rateCategor);
				likelihoodPosGivenSp+=likelihoodPosGivenSpGivenRate;
			}
			likelihoodPosGivenSp*=_spVecDistr->ratesProb(spVecCategor);
			likelihoodPos+=likelihoodPosGivenSp;
		}
		int pos_in_refseq = positionsDataItr->getPosInRefSeq()+1;
		_nodesData.resize(_et.getNodesNum());

		for (tree::nodeP mynode = tIt.first(); mynode != tIt.end(); mynode = tIt.next()) {

			_nodesData[mynode->id()].setInfo(mynode->id(), mynode->name(),mynode->dis2father());

			if (mynode->isRoot() == false)	{
				doubleRep sumTest(0.0);

				for(int letter1=0; letter1<alphSize;++letter1) {
					for(int letter2=0; letter2<alphSize;++letter2) {
						mutationProbs[mynode->id()][letter1][letter2]/=likelihoodPos;

						if (mutationProbs[mynode->id()][letter1][letter2]>1 + epsilon) {
							string err = "mutationMapping4site::fillBranchesData ERROR !!! mutation prob for pos " + int2string(pos_in_refseq) + ", node ";
							err+=int2string(mynode->id()) + " letter1 " + int2string(letter1) + " letterFather " + int2string(letter2);
							err+= " = ";
							err+=double2string(mutationProbs[mynode->id()][letter1][letter2]) ;
							err+="likelihood of pos= "+double2string(likelihoodPos);
							errorMsg::reportError(err);
						}

						if ((letter1 != letter2) && (mutationProbs[mynode->id()][letter1][letter2] > cutoff) ) {
							out<<pos_in_refseq<<"\t"<<mynode->id()<<"\t"<<mynode->name()<<"\t"<<mynode->getDistance2ROOT()<<"\t"<<letter2<<"\t"<<letter1<<"\t"<<mutationProbs[mynode->id()][letter1][letter2]<<endl;
							//_nodesData[mynode->id()] = nodeData(mynode->id());

							_nodesData[mynode->id()].addPosition(pos_in_refseq,letter2,letter1,mutationProbs[mynode->id()][letter1][letter2]);
						}

						sumTest+=mutationProbs[mynode->id()][letter1][letter2];
					}
				}

				if ((sumTest + epsilon < 1.0) || (sumTest > 1.0 + epsilon))
				{
					string err = "mutationMapping4site::fillBranchesData ERROR !!! sumTest = ";
					err+=double2string(sumTest);
					errorMsg::reportError(err); 
				}

			}
		}
	}	
}

void mutationMapping4site::printSeqTrajectories(MDOUBLE threshold,ostream &out) {
	treeIterDownTopConst tIt(_et);
	vector<tree::nodeP> leaves;
	_et.getAllLeaves(leaves,_et.getRoot());
	for(int leaf=0; leaf<leaves.size();++leaf) {
		vector<tree::nodeP> vPathVector;
		getPathFromROOT2Node(vPathVector, leaves[leaf]);
		out<<leaves[leaf]->name()<<"\t";

		for(int node=0; node<vPathVector.size();++node) {

			out<<_nodesData[vPathVector[node]->id()].data2print()<<"\t";
		}
		out<<"\n";

	}

}

void mutationMapping4site::calcPosUpAndDown(const posData& positionData,computePijGamSpVec& pij,  VVdouble &initFreqs)
{
	computeUpAlg cupAlg;
	computeDownAlg cdownAlg;

	int pos_in_MSA = positionData.getPosInMSA();
	int letterAtRoot = positionData.getRefSeqContent();

	for (int spVecCategor = 0; spVecCategor < _spVec.size(); ++spVecCategor) {
		for (int rateCategor = 0; rateCategor < _spVec[0]->categories(); ++rateCategor) {
			if (!_sscUpAllPos)
				cupAlg.fillComputeUp(_et,_sc,pos_in_MSA,pij[spVecCategor][rateCategor],_cup[spVecCategor][rateCategor]);
			else {
				_cup = (*_sscUpAllPos)[pos_in_MSA];
			}

			if (_rootKnown) {
				suffStatGlobalGamPos _cdownGivenRoot; // temporary holder.
				// non-reversible filling of down is used since it assumes a fixed position of the root (summation over content at root)
				cdownAlg.fillComputeDownNonReversible(_et,_sc,pos_in_MSA,pij[spVecCategor][rateCategor],_cdownGivenRoot,_cup[spVecCategor][rateCategor], &(initFreqs[spVecCategor]));
				_cdown[spVecCategor][rateCategor] = _cdownGivenRoot[letterAtRoot];

			}
			else {
				cdownAlg.fillComputeDown(_et,_sc,pos_in_MSA,pij[spVecCategor][rateCategor],_cdown[spVecCategor][rateCategor],_cup[spVecCategor][rateCategor]);
			}

		}
	}

}


doubleRep mutationMapping4site::calcJointProbGivenSpAndRate(int node_id, int spVecCategor, int rateCategor, computePijHom& pijGivenSpAndRate,
		int letter, int fatherLetter,MDOUBLE initFreq) const
{
	doubleRep downVal(0.0),upVal(0.0),val(0.0);
	MDOUBLE pijVal(0.0);


	MDOUBLE spProb = _spVecDistr->ratesProb(spVecCategor);
	MDOUBLE rateProb = _spVec[0]->ratesProb(rateCategor);
	pijVal = pijGivenSpAndRate.getPij(node_id,fatherLetter,letter);
	upVal = _cup[spVecCategor][rateCategor].get(node_id,letter);
	// note: this is the downAlg result for the father of mynode
	downVal = _cdown[spVecCategor][rateCategor].get(node_id,fatherLetter);
	val= initFreq*spProb*rateProb*upVal*downVal*pijVal;

	return val;
}
