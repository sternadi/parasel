#include "likelihoodComputationSPvecNonStationary.h"

#include "definitions.h"
#include "tree.h"
#include "computeUpAlg.h"
#include "likelihoodComputation.h"
#include "seqContainerTreeMap.h"

#include <cmath>
#include <cassert>


using namespace likelihoodComputationSPvecNonStationary;



MDOUBLE likelihoodComputationSPvecNonStationary::getTreeLikelihood(const tree& et,
							const sequenceContainer& sc,
							const vector<stochasticProcess*>& spVec,const distribution * spVecDistr, const VVVdouble &initFreqs) {


	computePijGamSpVec pi;
	pi.fillPij(et,spVec);

	suffStatGlobalGamSpVec ssc;
	computeUpAlg cup;
	cup.fillComputeUp(et,sc,pi,ssc);


	MDOUBLE res = getTreeLikelihoodUpIsFilled(et,sc,ssc,spVecDistr,spVec[0]->distr(),initFreqs);

	return res;
}


MDOUBLE likelihoodComputationSPvecNonStationary::getTreeLikelihoodUpIsFilled(const tree& et,
						const sequenceContainer& sc,
						const suffStatGlobalGamSpVec& ssc,const distribution * spVecDistr, const distribution *rateDistr, const VVVdouble &initFreqs){
	if (initFreqs.size() != sc.seqLen())
		errorMsg::reportError("Error in likelihoodComputationSPvecNonStationary::getTreeLikelihoodUpIsFilledSelectionGam: initiFreqs is not of size of seqeunce container");
	MDOUBLE res = 0.0;
	if (ssc.size()<= 0)
		errorMsg::reportError("Error in likelihoodComputationSPvecNonStationary::getTreeLikelihoodUpIsFilledSelectionGam: ssc is not filled");

	for (int pos=0; pos < sc.seqLen(); ++pos) {
		MDOUBLE lnL = log(getProbOfPosUpIsFilledSelectionGam(pos,
			  et,
			  sc,
			  ssc[pos], // ssc per position
			  spVecDistr, rateDistr,initFreqs[pos]));
		res += lnL;
	}
	return res;
}

MDOUBLE likelihoodComputationSPvecNonStationary::getProbOfPosUpIsFilledSelectionGam(const int pos,const tree& et,
						const sequenceContainer& sc,
						const suffStatGlobalGamSpVecPos& cup,const distribution * spVecDistr,
						const distribution *rateDistr, const VVdouble &initFreqsForPos){

	if (initFreqsForPos.size() != spVecDistr->categories())
		errorMsg::reportError("Error in likelihoodComputationSPvecNonStationary::getProbOfPosUpIsFilledSelectionGam: initFreqsForPos is not of size of number of categories");
	doubleRep res=0.0;
	for (int spVecCategor = 0; spVecCategor < spVecDistr->categories() ; ++spVecCategor) {
		doubleRep llGivenGivenSpVec=0;
		for (int rateCategor = 0; rateCategor < rateDistr->categories(); ++rateCategor) {
			doubleRep llGivenRateGivenSpVec =0;
			for (int let =0; let < sc.alphabetSize(); ++let) {
				llGivenRateGivenSpVec+=cup.get(spVecCategor,rateCategor,et.getRoot()->id(),let)
						* initFreqsForPos[spVecCategor][let]; // rootIndicator: 0 if not present in root, 1 otherwise; stationarity: freqs for sp (regardless of pos)

			}
			llGivenRateGivenSpVec *=rateDistr->ratesProb(rateCategor);

			llGivenGivenSpVec+=llGivenRateGivenSpVec;

		}
		llGivenGivenSpVec*=spVecDistr->ratesProb(spVecCategor);

		res+=llGivenGivenSpVec;

	}
	if (!(res>0.0)) {
		cerr<<"likelihood of pos "<<pos<<"="<<convert(res)<<endl;
		errorMsg::reportError("Error in likelihoodComputationSPvecNonStationary::getProbOfPosUpIsFilledSelectionGam: negative likelihood");
	}
	return convert(res);
}



MDOUBLE likelihoodComputationSPvecNonStationary::getLofPosGivenSpVecCategor(const int pos,
					  const tree& et,
					  const sequenceContainer& sc,const distribution *rateDistr,
					  const suffStatGlobalGamPos& ssc, Vdouble &initFreqForPosAndSp)
{



	doubleRep res = 0.0;
// need to sum over rate categories here!
	for (int rateCategory=0; rateCategory<rateDistr->categories(); ++rateCategory){
		doubleRep LGivenRate = 0.0;
		for (int let = 0; let < sc.alphabetSize(); ++let) { // letter at root
			doubleRep tmpLcat = 	ssc.get(rateCategory,et.getRoot()->id(),let)*initFreqForPosAndSp[let];
			if (!DBIG_EQUAL(convert(tmpLcat), 0.0)) {
				cerr<<"tmpLcat = "<<tmpLcat<<endl;
				errorMsg::reportError("error in likelihoodComputationSPvecNonStationary::getLofPosGivenSpVecCategor. likelihood is smaller than zero");
			}
			LGivenRate+=tmpLcat;
		}
		res+=LGivenRate * rateDistr->ratesProb(rateCategory);
	}
	if (!DBIG_EQUAL(convert(res), 0.0)){
		LOG(5,<<"WARNING! likelihood set to epsilon for pos="<<pos<<" likelihoodComputationSPvecNonStationary::getLofPosGivenSpVecCategor: "<< convert(res)<<endl;);
		res = EPSILON;
	}

	MDOUBLE l =  convert(res);
	return l;
}



/*MDOUBLE likelihoodComputationSPvecNonStationary::getTreeLikelihoodFromUp2(const tree& et,
						const sequenceContainer& sc,
						const stochasticProcess& sp,
						const suffStatGlobalGam& cup,
						Vdouble& posLike, // fill this vector with each position likelihood but without the weights.
						const distribution * distr,
						const VVdouble &initFreqs,
						const Vdouble * weights) {
	posLike.clear();
	doubleRep like = 0;
	//computing the likelihood from up:
	for (int pos = 0; pos < sc.seqLen(); ++pos) {
		doubleRep tmp=0;
		for (int categor = 0; categor < distr->categories(); ++categor) {
			doubleRep veryTmp =0;
			for (int let =0; let < sc.alphabetSize(); ++let) {
				veryTmp+=cup.get(pos,categor,et.getRoot()->id(),let) * initFreqs[pos][let];
			}
			tmp += veryTmp*distr->ratesProb(categor);
		}
		if (!(tmp>0.0))
			errorMsg::reportError("Error in likelihoodComputationSPvecNonStationary::getTreeLikelihoodFromUp2: negative likelihood");
		like += log(tmp) * (weights?(*weights)[pos]:1);
		posLike.push_back(convert(tmp));
	}
	MDOUBLE l = convert(like);

	return l;

}*/
