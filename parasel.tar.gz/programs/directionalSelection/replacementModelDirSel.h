
#ifndef ___REPLACEMENT_MODEL_dirSel
#define ___REPLACEMENT_MODEL_dirSel

#include <cmath>
#include "replacementModel.h"
#include "distribution.h"
#include "fromQtoPt.h"
#include "errorMsg.h"
#include "definitions.h"

class replacementModeldirSel : public replacementModel
{
public:
	explicit replacementModeldirSel(const replacementModel* baseRM, MDOUBLE S, int letter, MDOUBLE *Sout = NULL, bool *selectionAgainst = NULL);
	explicit replacementModeldirSel(const replacementModeldirSel& other);
	~replacementModeldirSel();
	replacementModeldirSel& operator=(const replacementModeldirSel &other);
	const int alphabetSize() const;
	virtual replacementModel* clone() const  {return new replacementModeldirSel(*this);}
	const MDOUBLE Pij_t(const int i,const int j, const MDOUBLE d) const {
		return _q2pt.Pij_t(i,j,d);
	}
	const MDOUBLE dPij_dt(const int i,const int j, const MDOUBLE d) const{
		return _q2pt.dPij_dt(i,j,d);
	}
	const MDOUBLE d2Pij_dt2(const int i,const int j, const MDOUBLE d) const{
		return _q2pt.d2Pij_dt2(i,j,d);
	}
	
	const MDOUBLE freq(const int i) const {return _freq[i];}
	const MDOUBLE err_allow_for_pijt_function() const {return 1e-4;} // same as q2p definitions


	VVdouble getQ() const { return _Q;}
	Vdouble getFreqs() const {return _freq;}

	MDOUBLE sumPijQij() const;
	void norm(const MDOUBLE scale);

	void updateQ();
	void updateFreq();
	void updateBaseReplacementModel(const replacementModel* baseRM);
	q2pt getQ2pt() const {return _q2pt;} // used for debug only

	void setS(MDOUBLE S) {_S=S; updateQ();}
	const MDOUBLE getS() const {return _S;}

	void setSout(MDOUBLE Sout) {_Sout=Sout; updateQ();}
	const MDOUBLE getSout() const {return _Sout;}

	void compute_Pij_t_fromQ(const MDOUBLE d, VVdouble &Pt);
	bool pijt_is_prob_value(MDOUBLE val) const;
	bool areFreqsValid(Vdouble freq) const; // tests if frequencies are valid (>0, sum=1)


private:

	replacementModel* _baseRM;
	MDOUBLE _S; // selection coefficient scaled for population size S=2Ns
	int _letter ; //letter into which directional selection is operating
	q2pt _q2pt;
	Vdouble _freq; // equilibrium (stationary) distribution, calculated by raising Q to the power of inf
	VVdouble _Q;
	MDOUBLE _Sout; // selection coefficient out: selection against leaving the state
	bool _selectionAgainst; // is selection against or for a character, default is for
			
};

#endif 

