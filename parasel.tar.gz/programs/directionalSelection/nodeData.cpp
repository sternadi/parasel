#include "nodeData.h"
#include "definitions.h"
#include "errorMsg.h"
#include <iomanip>


nodeData::nodeData(int nodeId) : _nodeId(nodeId)
{
	//_positions.resize(0);

}

void nodeData::addPosition(int newPosition, int startLetter, int endLetter, MDOUBLE posterior) {
	_positions.push_back(nodePosData(_nodeId,newPosition, startLetter, endLetter, posterior));
}

string nodeData::data2print () {
	string toPrint = "";

	for (int posNum=0; posNum<_positions.size(); posNum++) {
		toPrint+=_nodeName+":"+double2string(_dis2father)+";";
		toPrint+=int2string(_positions[posNum].getPosNumber() )+".";
		toPrint +=_positions[posNum].getMutation();
		toPrint+="/";
	}
	return toPrint;
}
