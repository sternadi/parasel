#include "evalParam.h"
#include "computePijComponent.h"
#include "likelihoodComputationSPvecNonStationary.h"
#include "stochasticProcess.h"
#include "replacementModelDirSel.h"
#include "userDistribution.h"
#include "treeIt.h"
#include "hky.h"



/*******************************************

// EVALUATOR FOR NIELSEN'S LINE SEARCH CODE

*******************************************/

evalAllParamsOfdirSel::evalAllParamsOfdirSel( tree& et,
				   const sequenceContainer& sc,
				   const vector<stochasticProcess*> &spVec,
				   const VVVdouble &initFreqs,
				    userDistribution & distr,my_enums::modelNameType &model_name,
				    bool doOptBBLs,bool fixedS,bool fixedProbS, bool fixedAlpha, bool fixedKappa, bool fixedBeta, bool fixedTau,
				    bool fixedQ, MDOUBLE &bestTau)
    : _et(et),_sc(sc),_spVec(spVec),_initFreqs(initFreqs), _model_name(model_name),  _distr(distr),
      _doOptBBLs(doOptBBLs),_fixedS(fixedS), _fixedProbS(fixedProbS),  _fixedAlpha(fixedAlpha), _fixedKappa(fixedKappa),
      _fixedBeta(fixedBeta),_fixedTau(fixedTau),_fixedQ(fixedQ), _bestTau(bestTau)
{




}

evalAllParamsOfdirSel::~evalAllParamsOfdirSel(){

}


evalAllParamsOfdirSel::evalAllParamsOfdirSel(const evalAllParamsOfdirSel &other):
_et(other._et),_sc(other._sc),_initFreqs(other._initFreqs),_spVec(other._spVec), _model_name(other._model_name),_distr(other._distr),
_doOptBBLs(other._doOptBBLs), _fixedS(other._fixedS), _fixedProbS(other._fixedProbS), _fixedAlpha(other._fixedAlpha), _fixedKappa(other._fixedKappa), _fixedBeta(other._fixedBeta),
_fixedTau(other._fixedTau),_fixedQ(other._fixedQ), _bestTau(other._bestTau)
{


}

double evalAllParamsOfdirSel::operator()(const double x[],const void*) {

// DANGEROUS! I DO NOT TEST THE SIZE OF x HERE
	// ORDER OF PARAMETERS IS: branch lengths, S, prob(s), alpha, kappa, tau, q
	treeIterTopDownConst tIt(_et); //set branch lengths to values in x
	int i=0;
	if (_doOptBBLs) {
		for (tree::nodeP mynode = tIt.first(); mynode != tIt.end(); mynode = tIt.next()) {
			if (mynode->isRoot()) {
				continue;
			}
			mynode->setDisToFather(x[i]);
			++i;
		}
	}
	MDOUBLE p = -1.0;
	MDOUBLE q = -1.0;
	if (!_fixedS) {
		LOGnOUT(20,<<"S="<<x[i]<<",");
		updateS(x[i]);
		++i;
	}
	if (!_fixedProbS) {
//		LOGnOUT(20,<<"P="<<x[i]<<",");
		//updateProbS(x[i]);
		p = x[i];
		++i;
	}
	if (!_fixedAlpha) {
		LOGnOUT(20,<<"alpha="<<x[i]<<",");
		updateAlpha(x[i]);
		++i;
	}
	if (!_fixedKappa && _model_name == my_enums::hky){
		LOGnOUT(20,<<"K="<<x[i]<<",");
		updateKappa(x[i]);
		++i;
	}
	if (!_fixedBeta) {
		LOGnOUT(20,<<"beta="<<x[i]<<",");
		updateBeta(x[i]);
		++i;
	}

	if (!_fixedTau) {
		LOGnOUT(20,<<"tau="<<x[i]<<",");
		_bestTau = x[i];
		_et.multipleAllBranchesByFactor(_bestTau);
		++i;
	}
	if (!_fixedQ) {
//		LOGnOUT(20,<<"q="<<x[i]<<",");
		//updateQ(x[i]);
		q = x[i];
		++i;
	}
	if (p!= -1.0 && q!= -1.0) {
		LOGnOUT(20,<<"p="<<p<<","<<"q="<<q<<",");
		q = (1.0-p)*q; // q is relative proportion!
		update_both_p_and_q(p,q);
	}
	else if (p!=-1.0 && q==-1.0) {
		LOGnOUT(20,<<"p="<<p<<",");
		updateProbS(p);
	}
	else if (p==-1.0 && q!=-1.0) {
		LOGnOUT(20,<<"q="<<q<<",");
		updateQ(q);
	}

	double res = likelihoodComputationSPvecNonStationary::getTreeLikelihood(_et,_sc,_spVec,&_distr, _initFreqs);
	if (_bestTau!=1.0)
		_et.multipleAllBranchesByFactor(1.0/_bestTau);
	LOGnOUT(20,<<endl<<"ll = "<<res<<endl);

	return -res;
}

void evalAllParamsOfdirSel::updateS(MDOUBLE param){
// update the S in each of the stochastic processes!

	for (int i = 0; i< _spVec.size()-1; ++i){
		static_cast<replacementModeldirSel*>(_spVec[i]->getPijAccelerator()->getReplacementModel())->setS(param);
	}

}




void evalAllParamsOfdirSel::updateProbS(MDOUBLE param){
	int alphabetSize = _spVec[0]->alphabetSize();
	MDOUBLE oldP = _distr.ratesProb(0) * alphabetSize;
	Vdouble newProbs(_spVec.size(),0.0);

	for (int i=0; i<alphabetSize; ++i) // multiply only change selection categories (first alph ceatgories)
		 newProbs[i] = (param/alphabetSize);
	if (oldP==1.0) {
		MDOUBLE newValProb = (1.0-param) / (alphabetSize+1);
		for (int j=alphabetSize; j<newProbs.size(); ++j) {// correct all the rest of the probs
			newProbs[j] = newValProb;
		}
	}
	else {
		MDOUBLE factor = (1.0-param)/(1.0 - oldP);
		for (int j=alphabetSize; j<newProbs.size(); ++j) {// correct all the rest of the probs
			newProbs[j] = _distr.ratesProb(j) * factor;
		}
	}
	MDOUBLE sum = 0.0;
	for (int k=0; k<newProbs.size(); ++k) {
		sum+=newProbs[k] ;
	}
	if (abs(sum-1.0)> 0.000001 )
		errorMsg::reportError("evalParamsOfdirSelForBrent::updateProbS: sum of probs is not 1");
	_distr.resetProbs(newProbs);

}

void evalAllParamsOfdirSel::updateQ(MDOUBLE param){
	int alphabetSize = _spVec[0]->alphabetSize();
	MDOUBLE oldQ = _distr.ratesProb(alphabetSize) * alphabetSize;

	Vdouble newProbs(_spVec.size(),0.0);
	for (int i=alphabetSize; i<newProbs.size()-1; ++i) // all selection no change categories (excluding the no selection last category)
		 newProbs[i] = param/alphabetSize;
	if (oldQ==1.0) {
		MDOUBLE newValProb = (1.0-param) / (alphabetSize+1);
		for (int j=0; j<alphabetSize; ++j) // correct all the rest of the probs
			newProbs[j] = newValProb;
		newProbs[newProbs.size()-1] = newValProb;// last no selection caetgory
	}
	else {
	MDOUBLE factor = (1.0-param)/(1.0 - oldQ);
		for (int j=0; j<alphabetSize; ++j) // correct all the rest of the probs
			newProbs[j] = _distr.ratesProb(j) * factor;
		newProbs[newProbs.size()-1] = _distr.ratesProb(newProbs.size()-1) * factor;// last no selection caetgory
	}
	MDOUBLE sum=0.0;
	for (int k=0; k<newProbs.size(); ++k) {
		sum+=newProbs[k] ;
	}
	if (abs(sum-1.0)> 0.000001 )
		errorMsg::reportError("evalParamsOfdirSelForBrent::updateProbS: sum of probs is not 1");
	_distr.resetProbs(newProbs);

}

void evalAllParamsOfdirSel::update_both_p_and_q(MDOUBLE p, MDOUBLE q) {
	if ((p+q)>1.0)
		errorMsg::reportError("error in evalAllParamsOfdirSel::update_both_p_and_q, p+q>1");
	int alphabetSize = _spVec[0]->alphabetSize();
	Vdouble newProbs(_spVec.size(),0.0);
	for (int i=0; i<alphabetSize-1; ++i) // all selection no change categories (excluding the no selection last category)
		 newProbs[i] = p/alphabetSize;
	for (int j=alphabetSize; j<newProbs.size()-1; ++j) // all selection no change categories (excluding the no selection last category)
		 newProbs[j] = q/alphabetSize;
	newProbs[newProbs.size()-1] = 1.0-p-q;
	_distr.resetProbs(newProbs);
}

void evalAllParamsOfdirSel::updateKappa(MDOUBLE param){
	// update the base fifth model
	hky *base_model = static_cast<hky*>(_spVec[_spVec.size()-1]->getPijAccelerator()->getReplacementModel());
	base_model->changeTrTv(param);

	for (int i = 0; i< _spVec.size()-1; ++i){ // update kappa in all 4 dirSel models
		replacementModeldirSel* pRM = static_cast<replacementModeldirSel*>(_spVec[i]->getPijAccelerator()->getReplacementModel());
		pRM->updateBaseReplacementModel(base_model);
	}
}

void evalAllParamsOfdirSel::updateAlpha(MDOUBLE param){
	for (int i = 0; i< _spVec.size(); ++i){ // update alpha in all models
		static_cast<gammaDistribution*>(_spVec[i]->distr())->setAlpha(param);
	}
}

void evalAllParamsOfdirSel::updateBeta(MDOUBLE param){
	for (int i = 0; i< _spVec.size(); ++i){
		_spVec[i]->setRelaxationFactor(param);
	}
}

/****************************

// EVALUATOR FOR BRENT

*****************************/

evalParamsOfdirSelForBrent::evalParamsOfdirSelForBrent( tree& et,
				   const sequenceContainer& sc,
				   const vector<stochasticProcess*> &spVec,
				   const VVVdouble &initFreqs,
				    userDistribution & distr,my_enums::modelNameType &model_name,my_enums::paramName &optParamName,
				    suffStatGlobalGamSpVec *ssc)
    : _et(et),_sc(sc),_spVec(spVec),_initFreqs(initFreqs), _model_name(model_name), _paramName(optParamName), _distr(distr), _ssc(NULL)
{
	if (ssc) //pre-computed input up values
		_ssc = new suffStatGlobalGamSpVec(*ssc);
}

evalParamsOfdirSelForBrent::~evalParamsOfdirSelForBrent(){
	  if (_ssc != NULL) delete _ssc;
}


evalParamsOfdirSelForBrent::evalParamsOfdirSelForBrent(const evalParamsOfdirSelForBrent &other):
_et(other._et),_sc(other._sc),_initFreqs(other._initFreqs),_spVec(other._spVec), _model_name(other._model_name),_paramName(other._paramName),_distr(other._distr),
 _ssc(NULL)
{

	if (other._ssc)
		_ssc = new suffStatGlobalGamSpVec(*(other._ssc));
}



MDOUBLE evalParamsOfdirSelForBrent::operator()(MDOUBLE paramVal){

	switch (_paramName){
		case my_enums::S:
			updateS(paramVal);
			break;
		case my_enums::probS:
			updateProbS(paramVal);
			break;
		case my_enums::alpha:
			updateAlpha(paramVal);
			break;
		case my_enums::kappa:
			updateKappa(paramVal);
			break;
		case my_enums::beta:
			updateBeta(paramVal);
			break;
		case my_enums::tau:
			_et.multipleAllBranchesByFactor(paramVal);
			break;
		case my_enums::q:
			updateQ(paramVal);
			break;
		case my_enums::Sout:
			updateSout(paramVal);
			break;
		default:
			errorMsg::reportError("evalParamsOfdirSelForBrent::operator, illegal parameter name");
			break;
	}
	MDOUBLE res(0.0);
	if (!_ssc)
		res = likelihoodComputationSPvecNonStationary::getTreeLikelihood(_et,_sc,_spVec,&_distr, _initFreqs);
	else
		res = likelihoodComputationSPvecNonStationary::getTreeLikelihoodUpIsFilled(_et,_sc,*_ssc,&_distr,_spVec[0]->distr(),_initFreqs);

	if (_paramName == my_enums::tau)
		_et.multipleAllBranchesByFactor(1.0/paramVal);
	return -res;
}


void evalParamsOfdirSelForBrent::updateS(MDOUBLE param){ // S-in (column)
// update the S in  the stochastic processes of the P model only!
	int alphSize = _spVec[0]->alphabetSize();
	for (int i = 0; i< alphSize; ++i){
		static_cast<replacementModeldirSel*>(_spVec[i]->getPijAccelerator()->getReplacementModel())->setS(param);
	}
}

void evalParamsOfdirSelForBrent::updateSout(MDOUBLE param){ // S-out (row)
// update the S-out in each of the stochastic processes - only in the P-model
	int alphSize = _spVec[0]->alphabetSize();
	for (int i = 0; i< alphSize; ++i){
		static_cast<replacementModeldirSel*>(_spVec[i]->getPijAccelerator()->getReplacementModel())->setSout(param);
	}
}



void evalParamsOfdirSelForBrent::updateProbS(MDOUBLE param){
	int alphabetSize = _spVec[0]->alphabetSize();
	MDOUBLE oldP = _distr.ratesProb(0) * alphabetSize;
	Vdouble newProbs(_spVec.size(),0.0);

	for (int i=0; i<alphabetSize; ++i) // multiply only change selection categories (first alph ceatgories)
		 newProbs[i] = (param/alphabetSize);

	if (oldP==1.0) {
		MDOUBLE newValProb = (1.0-param) / (alphabetSize+1);
		for (int j=alphabetSize; j<newProbs.size(); ++j) {// correct all the rest of the probs
			newProbs[j] = newValProb;
		}
	}
	else {
		MDOUBLE factor = (1.0-param)/(1.0 - oldP);
		for (int j=alphabetSize; j<newProbs.size(); ++j) {// correct all the rest of the probs
			newProbs[j] = _distr.ratesProb(j) * factor;

		}
	}
	MDOUBLE sum = 0.0;
	for (int k=0; k<newProbs.size(); ++k) {
		sum+=newProbs[k] ;
	}
	if (abs(sum-1.0)> 0.000001 )
		errorMsg::reportError("evalParamsOfdirSelForBrent::updateProbS: sum of probs is not 1");
	_distr.resetProbs(newProbs);

}

void evalParamsOfdirSelForBrent::updateQ(MDOUBLE param){
	int alphabetSize = _spVec[0]->alphabetSize();
	MDOUBLE oldQ = _distr.ratesProb(alphabetSize) * alphabetSize;

	Vdouble newProbs(_spVec.size(),0.0);
	for (int i=alphabetSize; i<newProbs.size()-1; ++i) // all selection no change categories (excluding the no selection last category)
		 newProbs[i] = (param/alphabetSize);
	if (oldQ==1.0) {
		MDOUBLE newValProb = (1.0-param) / (alphabetSize+1);
		for (int j=0; j<alphabetSize; ++j) // correct all the rest of the probs
			newProbs[j] = newValProb;
		newProbs[newProbs.size()-1] = newValProb;// last no selection caetgory
	}
	else {
		MDOUBLE factor = (1.0-param)/(1.0 - oldQ);
		for (int j=0; j<alphabetSize; ++j) // correct all the rest of the probs
			newProbs[j] = _distr.ratesProb(j) * factor;
		newProbs[newProbs.size()-1] = _distr.ratesProb(newProbs.size()-1) * factor;// last no selection caetgory
	}
	MDOUBLE sum=0.0;
	for (int k=0; k<newProbs.size(); ++k) {
		sum+=newProbs[k] ;
	}
	if (abs(sum-1.0)> 0.000001 )
		errorMsg::reportError("evalParamsOfdirSelForBrent::updateProbS: sum of probs is not 1");
	_distr.resetProbs(newProbs);

}

void evalParamsOfdirSelForBrent::updateKappa(MDOUBLE param){
	// update the base fifth model
	hky *base_model = static_cast<hky*>(_spVec[_spVec.size()-1]->getPijAccelerator()->getReplacementModel());
	base_model->changeTrTv(param);

	for (int i = 0; i< _spVec.size()-1; ++i){ // update kappa in all 4 dirSel models
		replacementModeldirSel* pRM = static_cast<replacementModeldirSel*>(_spVec[i]->getPijAccelerator()->getReplacementModel());
		pRM->updateBaseReplacementModel(base_model);
	}
	_ssc=NULL;
}

void evalParamsOfdirSelForBrent::updateAlpha(MDOUBLE param){
	for (int i = 0; i< _spVec.size(); ++i){ // update alpha in all models
		static_cast<gammaDistribution*>(_spVec[i]->distr())->setAlpha(param);
	}
	_ssc=NULL;
}

void evalParamsOfdirSelForBrent::updateBeta(MDOUBLE param){
	for (int i = 0; i< _spVec.size(); ++i){ // update  in all models
		_spVec[i]->setRelaxationFactor(param);
	}
	_ssc=NULL;
}

