#include "posSdata.h"
#include <iostream>
#include "logFile.h"
#include <iomanip>

posData::posData(int pos_in_MSA, int pos_in_RefSeq,int refSeqContent) :
_pos_in_MSA(pos_in_MSA),
_pos_in_RefSeq(pos_in_RefSeq),
_refSeqContent(refSeqContent)

{
	_ML_S = 0;
}



void posData::addPosteriorProb(MDOUBLE posteriorProb) {
	_posteriorProbs.push_back(posteriorProb);
}

void posData::clearPosteriorProbs() {
	_posteriorProbs.clear();
}



void posData::printPostVal(ostream &out, const alphabet* alph){

	out<<_pos_in_RefSeq+1 <<"\t"<<_pos_in_MSA+1<<"\t"<<alph->fromInt(_refSeqContent)<<"\t";
	for (int cat = 0; cat < _posteriorProbs.size(); ++cat){
		out<<_posteriorProbs[cat]<<"\t";
	}


	out << endl;

}


bool posData::isDirectionalSelection (MDOUBLE cutoff) {
	bool isSignificant=false;
	for (int i= 0; i< _posteriorProbs.size()-1; ++i) {
		if (_posteriorProbs[i]>cutoff)
			isSignificant=true;
	}
	return isSignificant;
}



