#ifndef ___EVAL_PARAM
#define ___EVAL_PARAM

#include "definitions.h"
#include "dirSelOptions.h"
#include "tree.h"
#include "likelihoodComputation.h"
#include "likelihoodComputationSPvec.h"
#include "sequenceContainer.h"
#include "stochasticProcess.h"
#include "computeUpAlg.h"
#include "numRec.h"
#include "userDistribution.h"
#include "suffStatComponent.h"
#include "enum.h"
#include "evalParam.h"

class evalParamsOfdirSelForBrent;

class evalAllParamsOfdirSel{
public:
	explicit evalAllParamsOfdirSel( tree& et,
				const sequenceContainer& sc,
				const vector<stochasticProcess*> &spVec,
				const VVVdouble &initFreqs,
				 userDistribution & distr, my_enums::modelNameType &model_name,
				 bool doOptBBLs,bool fixedS,bool fixedProbS,  bool fixedAlpha,bool fixedKappa, bool fixedBeta,
				 bool fixedTau , bool fixedQ, MDOUBLE &bestTau);
	double operator()(const double x[],const void*);
	tree getTree() {return _et;}
    virtual ~evalAllParamsOfdirSel();
    evalAllParamsOfdirSel(const evalAllParamsOfdirSel &other);
	void updateS(MDOUBLE param);
	void updateProbS(MDOUBLE param);
	void updateKappa(MDOUBLE param);
	void updateAlpha(MDOUBLE param);
	void updateBeta(MDOUBLE param);
	void updateQ(MDOUBLE param);
	void update_both_p_and_q(MDOUBLE p, MDOUBLE q);

private:
    tree &_et;
	const sequenceContainer& _sc;
	const VVVdouble& _initFreqs;
	vector<stochasticProcess*> _spVec;
	userDistribution &_distr;
	my_enums::modelNameType _model_name; // base model
	bool _doOptBBLs;
	bool _fixedS;
	bool _fixedProbS;
	bool _fixedAlpha;
	bool _fixedKappa;
	bool _fixedBeta;
	bool _fixedTau;
	bool _fixedQ;
	MDOUBLE &_bestTau;



};


class evalParamsOfdirSelForBrent{

public:
	explicit evalParamsOfdirSelForBrent( tree& et,
				const sequenceContainer& sc,
				const vector<stochasticProcess*> &spVec,
				const VVVdouble &initFreqs,
				 userDistribution & distr, my_enums::modelNameType &model_name, my_enums::paramName &optParamName,
				 suffStatGlobalGamSpVec *ssc=NULL );
	MDOUBLE operator()(MDOUBLE paramVal);

    virtual ~evalParamsOfdirSelForBrent();
    evalParamsOfdirSelForBrent(const evalParamsOfdirSelForBrent &other);
	void updateS(MDOUBLE param);
	void updateSout(MDOUBLE param);
	void updateProbS(MDOUBLE param);
	void updateKappa(MDOUBLE param);
	void updateAlpha(MDOUBLE param);
	void updateBeta(MDOUBLE param);
	void updateQ(MDOUBLE param);

private:
    tree &_et;
	const sequenceContainer& _sc;
	const VVVdouble& _initFreqs;
	vector<stochasticProcess*> _spVec;
	userDistribution &_distr;
	my_enums::modelNameType _model_name; // base model
	my_enums::paramName _paramName;

	suffStatGlobalGamSpVec * _ssc;



};

#endif // ___EVAL_PARAM
