#include "directionalSelection.h"
#include "likeDist.h"
#include "recognizeFormat.h"
#include "someUtil.h"
#include "alphabet.h"
#include "nj.h"
#include "likelihoodComputation.h"
#include "numRec.h"
#include "evaluateCharacterFreq.h"
#include "readDatMatrix.h"
#include "amino.h"
#include "nucleotide.h"
#include "likelihoodComputationSPvecNonStationary.h"
#include "matrixUtils.h"
#include "evalParam.h"
#include "treeUtil.h"
#include "aaJC.h"
#include "nucJC.h"
#include "replacementModelDirSel.h"
#include "trivialAccelerator.h"
#include "userDistribution.h"
#include "posSdata.h"
#include "uniDistribution.h"
#include "dirSelModel.h"
#include "tree.h"
#include "computeUpAlg.h"
#include "suffStatComponent.h"
#include "sequence.h"
#include "treeUtil.h"
#include "enum.h"
#include "mutationMapping4site.h"
#include "treeIt.h"


#ifdef WIN32	
#include <process.h>
#else
#include <unistd.h>
#endif

using namespace std;

int main(int argc, char** argv)
{

	directionalSelection ds(argc,argv);
	return 0;
}


/***********constructor***************/
directionalSelection::directionalSelection(int argc, char** argv) :
_pOptions(NULL),
_sc(NULL),
_dirSelModel(NULL),
_alph(NULL),
_refSeq(NULL)
{
	time_t t1;
	time(&t1);
	time_t t2;

	printInfo(cout);
	fillOptionsParameters(argc,argv);
	
	myLog::setLog(_pOptions->_logFile, _pOptions->_verboseLevel);
	myLog::printArgv(5,argc,argv);
	int pp = getpid();
	LOG(5,<<"#Process_id= "<<pp<<endl);
	_pOptions->printOptionParameters();
	
	run(argc, argv);

	time(&t2);
	LOG(5,<<endl<<"TOTAL RUNNING TIME = "<<(t2-t1)/60.0<<" minutes"<<endl);
	myLog::endLog();
}

/***********RUNS THE PROGRAM***************
1. Reads the seqeunce data and input tree 
2. Creates a vector of stochastic processs based on the substitution model
3. Optimizes the parameters of the model 
4. Computes posterior probability per site
***f******************************************************/
void directionalSelection::run(int argc, char** argv){

	initScAndTree(); // initialize sequence container and tree

	_dirSelModel = new dirSelModel(_pOptions,_t, *_sc);
	fill_initFreqs();
	bool allFixed = false;
	if ((_pOptions->_fixedS) && (_pOptions->_fixedProbS) && (_pOptions->_fixedKappa) && (!_pOptions->_bblOpt) && (_pOptions->_fixedAlpha) && (_pOptions->_fixedBeta) && (_pOptions->_fixedQ) && (_pOptions->_fixedTau))
		allFixed=true;
	optimizeParams();
	ofstream out(_pOptions->_outResFile.c_str());
	_dirSelModel->printModelParam(out,_pOptions);
	if (allFixed)
			out<<"#(Parameters were fixed)"<<endl;
		else
			out<<"#(Parameters are ML estimates)"<<endl;
	out.close();
	initPositionsData();
	fillPij();
	computePosteriorProbs();
	printResults();
	if (_pOptions->_doMutationMapping) {
		getNodesPosteriorProbs4significantSites();
	}

}


/***********destructor***************/
directionalSelection::~directionalSelection() {
	if (_pOptions) delete _pOptions;
	if (_sc) delete _sc;
	if (_alph) delete _alph;
	if (_refSeq) delete _refSeq;
	if (_dirSelModel) delete _dirSelModel;
}

void directionalSelection::printInfo(ostream& out) {
	out<<endl;
	out<<" ======================================================================="<<endl;
	out<<" The ParaSel program "<<endl;
	out<<" Version: 1.1 Last updated Nov 17 2015 "<<endl;
	out<<" For program support, please contact Adi Stern:"<<endl;
	out<<" sternadi1@gmail.com "<<endl;
	out<<" ======================================================================="<<endl;
	out<<endl;
}

void directionalSelection::fillOptionsParameters(int argc, char* argv[]) {

	string paramStr = argv[1];
	_pOptions = new dirSelOptions();
	_pOptions->initOptions(paramStr);
}

/******INITIALIZE SEQ CONTAINER & TREE*****
This function reads the alignment file
and reads either a user-tree file or creates a NJ tree 
******************************************/
void directionalSelection::initScAndTree(){
	switch (_pOptions->_alphabetSize) {
		case 4 : _alph = new nucleotide;  break;
		case 20 : _alph = new amino; break;
		default: errorMsg::reportError("Error in directionalSelection::initScAndTree, directionalSelection implements only amino and nucleotide alphabets");
	}
	ifstream in(_pOptions->_inSeqFile.c_str());
	_sc = new sequenceContainer(recognizeFormat::read(in, _alph));
	/***getting reference (query) sequence before gaps are changed to missing data*/
	int id;
	if (_pOptions->_inQuerySeq.size()==0) id = _sc->placeToId(0);
	else id  = _sc->getId(_pOptions->_inQuerySeq,false);

	if (id == -1) {
		id = _sc->placeToId(0);
		if (_pOptions->_useQueryFreqsAtRoot) {
			LOGnOUT(5,<<"***Query sequence not found:"<<_pOptions->_inQuerySeq<<endl);
			errorMsg::reportError("ERROR. Query sequence not found and _useQueryFreqsAtRoot invoked; cannot root the tree.");

		}
		LOGnOUT(5,<<"***WARNING: Query sequence not found"<<endl);
		LOGnOUT(5,<<"*** USING 1st sequence as query: $$$"<< (*_sc)[id].name()<<"$$$"<<endl);
	}
	_refSeq = new sequence((*_sc)[id]);

	_sc->changeGaps2MissingData();
	in.close();

	if (_pOptions->_inTreeFile.size()!=0){ //here checking if there is a user tree
		LOG(5,<<"-------------------------"<<endl);
		LOG(5,<<"Reading user tree "<<endl<<endl;); 
		tree et(_pOptions->_inTreeFile);
		_t = et;
	}
	else {
		createTree();
	}


	//root tree
	tree::nodeP rootNode = NULL;
	if (_pOptions->_useQueryFreqsAtRoot) {
		tree::nodeP queryNode = _t.findNodeByName(_pOptions->_inQuerySeq);
		rootNode = queryNode->father();
		_t.rootAt(rootNode);
	}
	if (!_pOptions->_useQueryFreqsAtRoot && _pOptions->_rootAt != "") {
		_t.rootAtOutGroup(_pOptions->_rootAt);

	}
	LOGnOUT(5,<<"rooted tree at "<<_t.getRoot()->name()<<endl);
	LOGnOUT(5,<<"root has "<<_t.getRoot()->getNumberOfSons()<<" sons:"<<endl);
	for (int i=0; i<_t.getRoot()->getNumberOfSons(); ++i)
		LOGnOUT(5,<<"son is "<<_t.getRoot()->getSon(i)->name()<<" id="<<_t.getRoot()->getSon(i)->id()<<endl);
	printTreeWithNodeIdBPStyle(_t,cout,true);
	cout<<endl;
	if (_pOptions->_fixedTau && _pOptions->_initTau!=1.0)
		_t.multipleAllBranchesByFactor(_pOptions->_initTau);

	cout<<"sum of BLs is "<<_t.getAllBranchesLengthSum()<<endl;




}

void directionalSelection::fill_initFreqs() {
	bool doQModel = false;
	if (_pOptions->_initQ!=0.0 || !_pOptions->_fixedQ )
		doQModel = true;

	_initFreqs.resize(_sc->seqLen());

	int alphSize = _alph->size();
	int spVecSize = _dirSelModel->getSpVecSize();

	for (int pos=0; pos < _sc->seqLen(); ++pos) {
		resizeMatrix(_initFreqs[pos],spVecSize,alphSize);
		for (int sp=0; sp<spVecSize; ++sp) {
			for (int letter=0; letter<alphSize; ++letter) {
				if (_pOptions->_useQueryFreqsAtRoot) { // // create initial frequencies as indicator function based on query freqs.
					_initFreqs[pos][sp][letter]  = ((*_refSeq)[pos]==letter?1:0);
					if ((*_refSeq)[pos] == _alph->gap() || (*_refSeq)[pos] == _alph->unknown())
						_initFreqs[pos][sp][letter] =  _dirSelModel->getStationaryFreq(sp,letter); /// if a gap then use stationary frequency
				}
				else { // STANDARD STATIONARY FREQUNECIES
					if (_pOptions->_useS0AtRoot && !doQModel)
						_initFreqs[pos][sp][letter] = _dirSelModel->getStationaryFreq(spVecSize-1,letter); // this is independent of position; stationary distribution is null one always
					else {
						//_initFreqs[pos][sp][letter] = _dirSelModel->getStationaryFreq(sp,letter); //q model and null model
						_initFreqs[pos][sp][letter] = _dirSelModel->getStationaryFreq(spVecSize-1,letter);
						if (doQModel) {
							if (sp<alphSize) {// first categories (P model) - S change from root to tips
								_initFreqs[pos][sp][letter] = _dirSelModel->getStationaryFreq(spVecSize-1,letter); // null stationary for p model

							}
						}
					}
				}
			}
		}
	}

}



/***********CREATE NJ TREE********************************
This function creates a NJ tree with a simple  model
*********************************************************/
void directionalSelection::createTree(){
	LOG(5,<<"-------------------------"<<endl);
	LOGnOUT(5,<<endl<<"Reconstructing NJ tree "<<endl<<endl;); 
	VVdouble distM;
	vector<string> names;
	names.resize(_sc->numberOfSeqs());
	distM.resize(_sc->numberOfSeqs());
	int i;
	for (i=0;i<distM.size();i++){
		distM[i].resize(distM.size());
		names[i]=((*_sc)[i].name());
	}	
	// creating a simplistic model for computing ML distances for a NJ tree
	uniDistribution distr;
	replacementModel *baseRM = NULL;
	if (_pOptions->_alphabetSize == 4)
		baseRM = new nucJC;
	else if (_pOptions->_alphabetSize == 20)
		baseRM = new aaJC;
	else 
		errorMsg::reportError("directionalSelection::createTree: Only amino and nucleotide alphabets implemented in directionalSelection");

	pijAccelerator* pij = new trivialAccelerator(baseRM);
	distribution* uni = new uniDistribution;
	stochasticProcess sp(uni,pij);
	delete pij;
	delete baseRM;
	delete uni;
	likeDist lkDist(sp);
	for ( i=0;i<_sc->numberOfSeqs();i++){
		for(int j=i+1;j<_sc->numberOfSeqs();j++){
			distM[i][j]= lkDist.giveDistance((*_sc)[i],(*_sc)[j],NULL);
		}
	}
	NJalg nj;	
	_t = nj.computeTree(distM,names);
}


/***********ML over the parameters***************
Finds best parameters
*********************************************************/

void directionalSelection::optimizeParams(){


	_dirSelModel->optimizeParameters(_t,*_sc,_initFreqs,_pOptions);
	_t.output(_pOptions->_outTreeFile);

}


/******************************************************
Print the results to the output file
*******************************************************/
void directionalSelection::printResults(){
	ofstream out(_pOptions->_outResFile.c_str(),ios::app);

	out.precision(2);
	out<<"#Results of analysis"<<endl;
	out<<"#Displayed on sequence "<<_refSeq->name()<<endl;
	out<<"#=========================================================================================================================================="<<endl;
	out<<"#POS(QUERY_SEQ)\t"<<"POS(ALN)\t"<<"RESIDUE\t"<<"POSTERIOR PROBABILITY OF DIRECTIONAL SELECTION "<<endl;
	out<<"\t\t\t";
	for (int i=0; i<_alph->size(); ++i) {
		out<<_alph->fromInt(i);
		out<<"\t";
	}

	out<<endl;
	LOG(5,<<endl<<"=========================================================================================================================================="<<endl);

	//int gapVal = _alph->gap();
	vector<posData>::iterator posDataItr;
	for (posDataItr=_positionsData.begin();posDataItr!=_positionsData.end();++posDataItr) {
		//int posContent = posDataItr->getRefSeqContent();
		//if (posContent==gapVal)
			//continue;
		posDataItr->printPostVal(out,_alph);
	}
	out.close();





}

void directionalSelection::fillPij() {
	distribution* spVecDistr = _dirSelModel->getSpDistr();
	int numOfSpCategories = spVecDistr->categories();

	_pij._V.resize(numOfSpCategories);
	vector<stochasticProcess*> spVec = _dirSelModel->getSpVec();
	for (int i=0; i < numOfSpCategories; ++i) {
		_pij._V[i].fillPij(_t,*spVec[i]); // will fill in with the gamma distribution within each sp
	}

	computeUpAlg cup;
	cup.fillComputeUp(_t,*_sc,_pij,_sscUp);


}

/*********Compute directionalSelection (S) values*************
Computes the Empirical Bayesian expectation of the posterior
estimators for S values
fills the vector _positionsData
*******************************************************/
void directionalSelection::computePosteriorProbs(){

	LOGnOUT(5,<<endl<<"Calculating posterior and expectation of posterior values for all sites"<<endl);
	vector<posData>::iterator posDataItr;
	MDOUBLE treeLL = 0.0;
	for (posDataItr=_positionsData.begin();posDataItr!=_positionsData.end();++posDataItr) {
		int pos_in_MSA = posDataItr->getPosInMSA();
		LOG(5,<<"Likelihood of position "<<pos_in_MSA+1<<endl);
		treeLL+=log(computePosteriorProb4site(pos_in_MSA, *posDataItr));
	}
	LOGnOUT(5,<<"Likelihood of alignment and tree =  "<<treeLL<<endl);
}

void directionalSelection::initPositionsData() {
	int noOfgaps=0;
	int gapVal = _alph->gap();
	for (int pos_in_MSA=0; pos_in_MSA < _sc->seqLen(); ++pos_in_MSA) {
		int curPosContent = (*_refSeq)[pos_in_MSA];
		int pos_in_refSeq(-1);
		if (curPosContent==gapVal) {
			noOfgaps++;
		} else {
			pos_in_refSeq = pos_in_MSA-noOfgaps;
		}
		posData pos_data(pos_in_MSA,pos_in_refSeq,curPosContent);
		_positionsData.push_back(pos_data);
	}
}

MDOUBLE directionalSelection::computePosteriorProb4site(const int pos, posData& pos_data){
	distribution* spVecDistr = _dirSelModel->getSpDistr();

	// here we compute the posterior P(S|data) = P(S)*P(data|S) / P(data)
	VdoubleRep dblRepPosteriorV(spVecDistr->categories(),0.0); // temporary dblRep container for posterior values
	doubleRep dblRepTotalLikelihood(0.0);// temporary dblRep container for total likelihood

	int actual_pos_number = pos+1;
	MDOUBLE posLL=0.0;
	for (int i=0; i < spVecDistr->categories(); ++i) {
		MDOUBLE posLGivenSpVec = likelihoodComputationSPvecNonStationary::getLofPosGivenSpVecCategor(pos,_t,*_sc,_dirSelModel->getSpVec()[0]->distr(),_sscUp[pos][i],_initFreqs[pos][i]); // l of pos given S catgeory
		dblRepPosteriorV[i] = 	    posLGivenSpVec;
		LOG(5,<<"  Likelihood of directional selection to letter  "<<i<<" = "<<convert(dblRepPosteriorV[i])<<"\t");
		dblRepPosteriorV[i] *= spVecDistr->ratesProb(i); // prior
		LOG(5,<<", prior =  "<<i<<" = "<<spVecDistr->ratesProb(i)<<endl);
	    dblRepTotalLikelihood+=dblRepPosteriorV[i];
	    posLL+=posLGivenSpVec*spVecDistr->ratesProb(i);
	}
	LOG(5,<<"total position "<<actual_pos_number<<" likelihood is "<<convert(dblRepTotalLikelihood)<<endl);
	if (!(dblRepTotalLikelihood!=0))
		errorMsg::reportError("Error in directionalSelection::computePosteriorProb4site, likelihood = 0");

	// here we divide by total likelihood to obtain the posterior (prior * l|S_category / l_Of_pos)
	for (int j=0; j < spVecDistr->categories(); ++j) {
		dblRepPosteriorV[j]/=dblRepTotalLikelihood;
		MDOUBLE posteriorVal = convert(dblRepPosteriorV[j]);
		pos_data.addPosteriorProb(posteriorVal); // revert back to DOUBLE
	//	if ((j != spVecDistr->categories()-1) && (posteriorVal>_pOptions->_threshold))
	//		site_specific_ML_over_S(pos, pos_data);
	}
	return posLL;
}



void directionalSelection::getNodesPosteriorProbs4significantSites()
{
	 distribution* spVecDistr = _dirSelModel->getSpDistr();
	 vector<stochasticProcess*> spVec = _dirSelModel->getSpVec();
	mutationMapping4site map_nodesProbs(_t,*_sc,spVec,spVecDistr,*_refSeq, _pOptions->_useQueryFreqsAtRoot, &_sscUp);

	string nodesFile = _pOptions->_outResFile + ".mutation.map";
	ofstream out2(nodesFile.c_str());

	map_nodesProbs.computeSignificantBranches(_positionsData,_pOptions->_threshold,_pij, _initFreqs, out2);
	out2.close();

	string trajectoriesFile = _pOptions->_outResFile + ".mutation.trajectories";
	ofstream out3(trajectoriesFile.c_str());
	map_nodesProbs.printSeqTrajectories(_pOptions->_threshold,out3);
	out3.close();
}


void directionalSelection::site_specific_ML_over_S(int pos, posData& pos_data) {
	Vint pos_to_remove(_sc->seqLen(), 1.0);
	for (int i=0; i < _sc->seqLen(); ++i) {
		if (i==pos)
			pos_to_remove[i]=0;
	}
	sequenceContainer scPos(*_sc, _alph); // a copy of the original sequence container
	scPos.removePositions(pos_to_remove);

	VVVdouble initFreqsPerPos;
	initFreqsPerPos.resize(1);

	resizeMatrix(initFreqsPerPos[0],_dirSelModel->getSpVecSize(),_alph->size());
	initFreqsPerPos[0] = _initFreqs[pos];

	MDOUBLE expectation_posteriorProbS = 0;
	MDOUBLE likeOfPos = 0;
	Vdouble posteriorPos;
	Vint w_vals (10);

	for (int i=0; i<w_vals.size(); ++i) {
		w_vals[i] = (i+0.5)*2;
	}
	for (int j=0; j<w_vals.size(); ++j) {


		for (int i = 0; i< _dirSelModel->getSpVecSize()-1; ++i){
			static_cast<replacementModeldirSel*>(_dirSelModel->getSpVec()[i]->getPijAccelerator()->getReplacementModel())->setS(w_vals[j]);
		}
		MDOUBLE val = _dirSelModel->compLogLikelihood(_t,scPos,initFreqsPerPos) ;
		val/=w_vals.size();
		cout<<" val/prior="<<val<<endl;
		posteriorPos.push_back(val);
		likeOfPos+=val;
	}
	for (int i=0; i< posteriorPos.size(); ++i) {
		posteriorPos[i]/=likeOfPos;
		int S=w_vals[i];
		expectation_posteriorProbS += posteriorPos[i]*S;
	}
	//_dirSelModel->optimizeParameters(_t,scPos,initFreqsPerPos,&posOptions);
	//pos_data.addML_S(_dirSelModel->getBestS());
	pos_data.addML_S(expectation_posteriorProbS);


}







