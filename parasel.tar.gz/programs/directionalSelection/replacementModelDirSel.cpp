// 	$Id: replacementModeldirSel.cpp 4165 2008-06-04 09:19:48Z osnatz $

#include "replacementModelDirSel.h"
#include "logFile.h"
#include "matrixUtils.h"
#include "someUtil.h"
#include <iomanip>
#include <iostream>


replacementModeldirSel::replacementModeldirSel(const replacementModel* baseRM, MDOUBLE S, int letter,MDOUBLE *Sout/*=NULL*/,bool *selectionAgainst /*= NULL*/) :
_baseRM(baseRM->clone()),
_S(S),
_letter(letter)
{
	if (Sout)
		_Sout = *Sout;
	else
		_Sout = _S;
	if (selectionAgainst)
		_selectionAgainst = true;
	else
		_selectionAgainst = false;
	updateQ();
}



replacementModeldirSel::replacementModeldirSel(const replacementModeldirSel& other) :
_baseRM(other._baseRM->clone()),	
_S(other._S),
_letter(other._letter),
_q2pt(other._q2pt),
_freq(other._freq),
_Q(other._Q),
_Sout(other._Sout),
_selectionAgainst(other._selectionAgainst)
{
}

replacementModeldirSel::~replacementModeldirSel()
{
	if (_baseRM) delete (_baseRM);
}


replacementModeldirSel& replacementModeldirSel::operator=(const replacementModeldirSel &other)
{
	if (_baseRM) delete (_baseRM);
	_baseRM = other._baseRM->clone();	
	_S = other._S;
	_letter = other._letter;
	_q2pt = other._q2pt; //@@@@ why doesn't this work ? explicit ? (need to test this - Adi)
//	_q2pt.fillFromRateMatrix(other._freq,other._Q);
	_freq = other._freq;
	_Q = other._Q;
	_Sout = other._Sout;
	_selectionAgainst = other._selectionAgainst;
	return (*this);
}

const int replacementModeldirSel::alphabetSize() const
{
	return (_baseRM->alphabetSize() );
}



// calculate Pt^inf as stationary distribution
void replacementModeldirSel::updateFreq()
{
	VVdouble P;
	compute_Pij_t_fromQ(0.1,P);

	int alphSize = alphabetSize();

	VVdouble previous_P = P;
	int numIterations = 0;
	Vdouble freqs(alphSize,-1.0);
	bool converged = false;
	MDOUBLE epsilon=0.000001;
	int row, col;

	while ( converged==false ) {
		previous_P = P;
		P = multiplyMatrixes(P,P);

		// due to rounding errors, we set the diagonal to be 1-(the rest)
		/*for (int j=0; j< alphSize; ++j) {
			MDOUBLE sum_row;
			for (int k=0; k< alphSize; ++k) {
				if (!(j==k))
					sum_row+=P[j][k];
			}
			//P[j][j]=1.0-sum_row;
		}*/

		for (int i=0; i<alphSize;++i){
			freqs[i] = P[i][i];// ** taking the freqs as the first row; this is not necessarily correct if all rows are different

		}
		converged = true;
		for (row = 0; row < P.size(); ++row) {
			for (col = 0; col < P.size(); ++col)
			{
				MDOUBLE diff = abs(convert(previous_P[row][col] - P[row][col]));

				if ( ( ( ( !DEQUAL(diff,0.0,epsilon) ) || (!areFreqsValid(freqs) ) ) )){
					converged = false;
				}
			}
		}
		numIterations++;
		if (numIterations>120) {
			string err = "Error in replacementModeldirSel::updateFreq, too many iterations =" + double2string(numIterations);
			err+=" S is "+double2string(_S);
			err+=" letter is "+int2string(_letter);
			errorMsg::reportError(err);
		}

	}
//making sure that the  rows are the same
	for (row =1; row < P.size(); ++row) {
	    for (col = 0; col < P.size(); ++col) {
	    	if (!(DEQUAL(P[row][col],P[row-1][col],epsilon))) {
//	    		errorMsg::reportError("Error in replacementModeldirSel::updateFreq, rows are not equal"    );

	    	}

	    }

	}

	_freq=freqs;


}

bool replacementModeldirSel::areFreqsValid(Vdouble freq) const{
	MDOUBLE sum=0.0;
	for (int i=0; i<freq.size(); ++i){
		if (freq[i]<0.0)
			return false;
		sum+=freq[i];
	}
	if (!DEQUAL(sum,1.0)) {
		return false;
	}
	return true;
}

// calculate Pt directly from Pt as I + Qt + Qt^2/2! + ....  + Qt^n/n!
void replacementModeldirSel::compute_Pij_t_fromQ(const MDOUBLE d, VVdouble &Pt) {
	// converting Q into doubleRep format
	VVdoubleRep QdblRep;
	resizeMatrix(QdblRep,_Q.size(),_Q.size());
	for (int row=0;row<_Q.size();row++){
			for (int col=0;col<_Q[row].size();col++)
				QdblRep[row][col]=convert(_Q[row][col]);
	}

	VVdoubleRep Qt = multiplyMatrixByScalar(QdblRep, d);
	VVdoubleRep unit;
	unitMatrix(unit,_Q.size());
	VVdoubleRep lastPtCalculated = add(unit,Qt) ; // I + Qt
	VVdoubleRep Qt_power = Qt;
	VVdoubleRep prevIter_matrix = lastPtCalculated;
	VVdoubleRep diffM = lastPtCalculated; //init to whatever
	int n=2;
	bool bConverged = false;
	while (bConverged == false)
	{
		prevIter_matrix = lastPtCalculated;
		VVdoubleRep tempQ = multiplyMatrixByScalar(Qt,1.0/n);
		Qt_power = multiplyMatrixes(Qt_power,tempQ);
		lastPtCalculated = add(lastPtCalculated,Qt_power); // I + Qt + Qt^2/2! + ....  + Qt^n/n!
		//check if the difference between the cur and prev iteration is smaller than the allowed error of all matrix entries
		bConverged = true;
		for (int row = 0; row < lastPtCalculated.size(); ++row) {
			for (int col = 0; col < lastPtCalculated.size(); ++col)
			{
				MDOUBLE diff = abs(convert(lastPtCalculated[row][col] - prevIter_matrix[row][col]));
				if ((diff > err_allow_for_pijt_function()) || (!pijt_is_prob_value(convert(lastPtCalculated[row][col]))))
					bConverged = false;
			}
		}
		n++;
		if (n>150) {
			string err = "Error in replacementModeldirSel::compute_Pij_t_fromQ, too many iterations for t = " + double2string(d);
			//cerr<<diff<<endl;
			errorMsg::reportError(err);
		}
	}

	resizeMatrix(Pt,_Q.size(),_Q.size());
	for (int row = 0; row < lastPtCalculated.size(); ++row) {
		for (int col = 0; col < lastPtCalculated.size(); ++col)
		{
			MDOUBLE val = convert(lastPtCalculated[row][col]);

			if (!pijt_is_prob_value(val))
				errorMsg::reportError("Error in replacementModeldirSel::compute_Pij_t_fromQ, pijt <0 or >1");

			if (val<0.0)
				val = EPSILON; // absolute zero creates a problem later on in computations
			if (val>1.0)
				val = 1.0;
			Pt[row][col]=val;
		}
	}


}

bool replacementModeldirSel::pijt_is_prob_value(MDOUBLE val) const {
	if ((abs(val)+err_allow_for_pijt_function()<0) || (val>1+err_allow_for_pijt_function()))
		return false;
	else
		return true;
}


void replacementModeldirSel::updateQ()
{
//	if (!(_S>0) ) {
//		errorMsg::reportError("input error in replacementModeldirSel::updateQ: S must be larger than 0");
//	}
	if (_selectionAgainst) {
		if (_S>0) _S=-_S; cout<<"S is "<<_S<<endl;
	}
	else {
		if (!(_S>0) ) {
				errorMsg::reportError("input error in replacementModeldirSel::updateQ: S must be larger than 0");
		}
	}
	_Q.clear();
	int size = alphabetSize();
	_Q.resize(size);
	for (int z=0; z < _Q.size();++z) 
		_Q[z].resize(size,0.0);
	
	// fill Q
	for (int i=0; i < size; ++i) 	{
		MDOUBLE sum_row = 0;
		for (int j=0; j < size; ++j) {
			if (i==j)
				continue; // to be filled in later
			if (j==_letter) // selection for this character
				_Q[i][j] = _baseRM->dPij_dt(i,j,0) * _S/(1-exp(-_S));
				//_Q[i][j] = _baseRM->dPij_dt(i,j,0) * _S/(exp(_S)-1); // selection against entering this character (OPPOSITE!)
			else if (i==_letter) // selection against leaving this character
				_Q[i][j] = _baseRM->dPij_dt(i,j,0) * _Sout/(exp(_Sout)-1); // this assumes negative selection = -S
				//_Q[i][j] = _baseRM->dPij_dt(i,j,0) * _S/(1-exp(-_S)); // selection FOR leaving this char (OPPOSITE!)
			else
				_Q[i][j] = _baseRM->dPij_dt(i,j,0);

			sum_row+=_Q[i][j];
		}
		_Q[i][i] = -sum_row;
	}


	updateFreq(); // calculate stationary distribution (pi); this is to allow use of Q2P (diagonalization of Q requires pi for a symmetric matrix, and allows faster ll calc)
	norm(1.0/sumPijQij()); // normalize so average rate of substitution = 1
	_q2pt.fillFromRateMatrix(_freq,_Q);
/*	cout<<"matrix "<<endl; //debug
	printMatrix(_Q,cout);; //debug
	cout<<"freqs "<<endl;
	for (int q=0;q<_freq.size(); q++) cout<<_freq[q]<<" "; //debug
	cout<<endl;*/
}

void replacementModeldirSel::updateBaseReplacementModel(const replacementModel* baseRM) {
	if (_baseRM) delete (_baseRM);
	_baseRM = baseRM->clone();
	updateQ();
}

void replacementModeldirSel::norm(const MDOUBLE scale)
{
	for (int i=0; i < _Q.size(); ++i) {
		for (int j=0; j < _Q.size(); ++j) {
			_Q[i][j] *= scale;
		}
	}
}

MDOUBLE replacementModeldirSel::sumPijQij() const{
	MDOUBLE sum=0.0;
	for (int i=0; i < _Q.size(); ++i) {
		sum -= (_Q[i][i])*_freq[i];
	}
	return sum;
}

