#ifndef __DIRSEL_MODEL
#define __DIRSEL_MODEL

#include "definitions.h"
#include "stochasticProcess.h"
#include "tree.h"
#include "sequenceContainer.h"
#include "gammaDistribution.h"
#include "talRandom.h"
#include "dirSelOptions.h"
#include "userDistribution.h"
#include "computeUpAlg.h"





/******************************************************
directional model assuming strong selection for a certain state (nuc/a.a.)
This is the surrounding model around the baseline model
*********************************************************/
class dirSelModel{
public:
	dirSelModel(dirSelOptions* pOptions,const tree& et,const sequenceContainer& sc);

	//dirSelModel(const dirSelModel& other);
	//void copy(const dirSelModel& other);
	virtual ~dirSelModel();
	
	//optimize the model param and return best log-likelihood
	void optimizeParameters(tree& et, 
		const sequenceContainer& sc,const VVVdouble &initFreqs,
		dirSelOptions* pOptions);
	

	MDOUBLE compLogLikelihood(const tree &et, const sequenceContainer &sc, const VVVdouble &initFreqs);
	
	void fillSuffStatGlobalGam(suffStatGlobalGam &ssc, const tree &et,  
		const sequenceContainer &sc);
	
	const MDOUBLE getBestS() const {return _bestS;}
	const MDOUBLE getBestProbS() const {return _bestProbS;}
	const MDOUBLE getBestAlpha() const {return _bestAlpha;}
	const MDOUBLE getBestKappa() const {return _bestKappa;}
	const MDOUBLE getBestL() const {return _bestL;}


	vector<stochasticProcess*> getSpVec() {return _spVec;}
	int getSpVecSize() {return _spVec.size();}
	distribution *getSpDistr() {return _spVecDistr;}
	MDOUBLE getStationaryFreq (int spVecNumber, int letter) ;
	void printModelParam(ofstream& outFile,dirSelOptions* pOptions) const;


private:
	void createSpVec(dirSelOptions* pOptions,const sequenceContainer& sc);

	void init(dirSelOptions* pOptions,const tree& et,const sequenceContainer& sc);
	void optimizeParametersLineSearch(tree& et,
		const sequenceContainer& sc,const VVVdouble &initFreqs,
		dirSelOptions* pOptions);
	void optimizeParametersBrent(tree& et,
		const sequenceContainer& sc,const VVVdouble &initFreqs,
		dirSelOptions* pOptions);
	void optimizeSpecificParameterBrent(tree& et, const sequenceContainer& sc,const VVVdouble &initFreqs,
										  dirSelOptions* pOptions, userDistribution *spVecDistr ,
										  MDOUBLE &bestVal, MDOUBLE lowerBound, MDOUBLE upperBound, my_enums::paramName optParamName, bool &changed);
	string getParamName(my_enums::paramName type);
	void setBestParamVal(my_enums::paramName paramName);

private:
	void getBLs(const tree &et, Vdouble &BLs);



private:
	vector <stochasticProcess*> _spVec; //save stochasticProcess for each category 
	distribution *_spVecDistr;

private:

	MDOUBLE _lowerBoundParams; // epsilon for lower bound which is normally zero
	MDOUBLE _upperBoundKappa;
	MDOUBLE _upperBoundAlpha;
	MDOUBLE _lowerBoundS;
	MDOUBLE _upperBoundS;
	MDOUBLE _lowerBoundProbS;
	MDOUBLE _upperBoundProbS;

	MDOUBLE _lowerBoundBeta;
	MDOUBLE _upperBoundBeta;

	MDOUBLE _lowerBoundTau;
	MDOUBLE _upperBoundTau;

	MDOUBLE _upperBoundBL;
	MDOUBLE _epsilonForBrent;
	MDOUBLE _epsilonLikelihood;


	MDOUBLE _bestS;
	MDOUBLE _bestProbS;
	MDOUBLE _bestKappa;// if hky
	MDOUBLE _bestAlpha;
	MDOUBLE _bestBeta; // relaxation factor for leaves

	MDOUBLE _bestTau; // scaling factor for tree

	MDOUBLE _bestQ; // probabilty of selection constant along the tree
	MDOUBLE _bestSout;
	MDOUBLE _bestL;


};
#endif // __dirSel_MODEL

