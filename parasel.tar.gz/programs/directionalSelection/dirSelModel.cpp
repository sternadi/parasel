#include "dirSelModel.h"
#include "trivialAccelerator.h"
#include "chebyshevAccelerator.h"
#include "aaJC.h"
#include "readDatMatrix.h"
#include "replacementModelDirSel.h"
#include "bblEMSPvec.h"
#include "evalParam.h"
#include "likelihoodComputationSPvecNonStationary.h"
#include "likelihoodComputation.h"
#include "computePijComponent.h"
#include "evaluateCharacterFreq.h"
#include "hky.h"
#include "uniDistribution.h"
#include "matrixUtils.h"
#include "bfgs.h"
#include "treeIt.h"
#include "tree.h"
#include "nucleotide.h"
#include "amino.h"
#include "talRandom.h"
#include "enum.h"
#include "gammaDistribution.h"
#include "gammaDistributionPlusInvariant.h"
#include "numRec.h"
#include <algorithm>

dirSelModel::dirSelModel(dirSelOptions* pOptions,const tree& et, const sequenceContainer& sc):
_spVecDistr(NULL)
{

	createSpVec(pOptions, sc);

	init(pOptions, et, sc);

}



/*dirSelModel::dirSelModel(const dirSelModel &other) :
_bestS(other._bestS),
_bestProbS(other._bestProbS),
_bestL(other._bestL)
{
	_spVec.resize(other._spVec.size(),NULL);
	for (int i = 0; i< other._spVec.size(); ++i){
		if (other._spVec[i])
			_spVec[i] = other._spVec[i]->clone();
	}
	_spVecDistr = other._spVecDistr->clone();

}
*/


dirSelModel::~dirSelModel()
{
	for (int i = 0; i< _spVec.size(); ++i){
		if (_spVec[i])
			delete _spVec[i];
	}
	if (_spVecDistr)
		delete _spVecDistr;
}

/*
void dirSelModel::copy(const dirSelModel& other)
{
	_bestS=other._bestS;
	_bestProbS=other._bestProbS;
	_bestL=other._bestL;

	for (int i = 0; i< _spVec.size(); ++i){
		if (_spVec[i]) delete (_spVec[i]);
	}
	_spVec.clear();
	_spVec.resize(other._spVec.size(),NULL);
	for (int i = 0; i< other._spVec.size(); ++i){
		if (other._spVec[i])
			_spVec[i] = other._spVec[i]->clone();
	}
	if (_spVecDistr)
		delete _spVecDistr;
	_spVecDistr =other._spVecDistr->clone();
}
*/

void dirSelModel::init(dirSelOptions* pOptions,const tree & et, const sequenceContainer &sc) {


	_bestS = pOptions->_initS;
	_bestProbS = pOptions->_initProbS;
	_bestKappa = pOptions->_initKappa;
	_bestAlpha = pOptions->_initAlpha;
	_bestBeta = pOptions->_initBeta;
	_bestTau = pOptions->_initTau;
	_bestQ = pOptions->_initQ;
	_bestSout = pOptions->_initSout;
	_bestL = 0.0; // indicator that no optimization was performed

}



void dirSelModel::createSpVec(dirSelOptions* pOptions,const sequenceContainer& sc) {
	// first create distribution over spVec (probability of each sp in spVec)
	bool doQModel = false;
	if (pOptions->_initQ!=0.0 || !pOptions->_fixedQ )
		doQModel = true;

	Vdouble spVecProbs;
	int alphSize = pOptions->_alphabetSize;
	int spVecSize = pOptions->_alphabetSize + 1;

	if (doQModel )
		spVecSize = alphSize*2 + 1;

	spVecProbs.resize(spVecSize);
	for (int i=0; i<alphSize; ++i) // first alphSize models are selection change models
		spVecProbs[i]=pOptions->_initProbS / alphSize;
	if (doQModel ) {
		for (int i=alphSize; i<spVecSize-1; ++i)
			spVecProbs[i]=pOptions->_initQ / alphSize;
	}

	spVecProbs[spVecSize-1] = 1.0 - pOptions->_initProbS - pOptions->_initQ; // last category is no selection at all
	Vdouble rates(spVecSize,1.0); // not used but required for distribution building!!

	_spVecDistr = new userDistribution(rates,spVecProbs);

	// now create spVec
	_spVec.resize(spVecSize);
	Vdouble freqObserved = evaluateCharacterFreq(sc);



	replacementModel *baseModel = NULL;// base model
	pijAccelerator *basePijAcc=NULL; // Accelerator for the base model

	switch (pOptions->_modelName) {
	case (my_enums::hky):
		baseModel = new hky(freqObserved,pOptions->_initKappa);
		basePijAcc = new trivialAccelerator(baseModel);
		break;
	case (my_enums::jtt):
		baseModel = new  pupAll(datMatrixHolder::jones);
		basePijAcc = new chebyshevAccelerator(baseModel);
		break;
	case (my_enums::rev):
		baseModel = new pupAll(datMatrixHolder::mtREV24);
		basePijAcc = new chebyshevAccelerator(baseModel);
		break;
	case (my_enums::day):
		baseModel=new pupAll(datMatrixHolder::dayhoff);
		basePijAcc = new chebyshevAccelerator(baseModel);
		break;
	case (my_enums::aajc):
		baseModel=new aaJC;
		basePijAcc = new chebyshevAccelerator(baseModel);
		break;
	case (my_enums::HIVb):
		baseModel = new pupAll(datMatrixHolder::HIVb);
		basePijAcc = new chebyshevAccelerator(baseModel);
		break;
	case (my_enums::HIVw):
		baseModel = new pupAll(datMatrixHolder::HIVw);
		basePijAcc = new chebyshevAccelerator(baseModel);
		break;
	default: errorMsg::reportError("dirSel::createSpVec: modelName is not supported");
	}

	int numCategories = 8;
	distribution* myDist = new gammaDistribution(pOptions->_initAlpha, numCategories);

	for (int counter=0; counter<spVecSize-1;counter++){ // beginning with directional selection models
		int letter = counter%alphSize;
		MDOUBLE S = pOptions->_initS;

		MDOUBLE *Sout=NULL;
		if (pOptions->_isSinSameAsSout == false)
			Sout = new MDOUBLE(pOptions->_initSout);
		if (counter>=alphSize) {
			S=10.0;
			Sout = new MDOUBLE (0.0001); // TEST: Q -model has out-rate of zero
		}
		bool *selectionAgainst = NULL;
		if (pOptions->_selectionAgainstChar)
			selectionAgainst = new bool (true);
		replacementModel * myModel = new replacementModeldirSel(baseModel,S,letter,Sout,selectionAgainst);
		delete selectionAgainst;
		delete Sout;
		pijAccelerator* pij = new trivialAccelerator(myModel);
		//stochasticProcess *sp = new stochasticProcess(uniDist,pij);
		stochasticProcess *sp = new stochasticProcess(myDist,pij,true,pOptions->_initBeta);
		_spVec[counter] = sp->clone();
		delete myModel;
		delete pij;
		delete sp;

	}
	// last category of spVec is the standard replacement model

	stochasticProcess *spBase = new stochasticProcess(myDist,basePijAcc, true, pOptions->_initBeta);

	_spVec[spVecSize-1] = spBase->clone();
	delete myDist;
	delete baseModel;
	delete basePijAcc;
	delete spBase;
/*	for (int i=0; i<alphSize; ++i) {
	cout<<_spVec[alphSize]->freq(i)<<"\t";
	cout<<_spVec[0]->freq(i)<<endl;
	}*/
}

MDOUBLE dirSelModel::getStationaryFreq (int spVecNumber, int letter)
{
	if (spVecNumber>= _spVec.size())
		errorMsg::reportError("Error in dirSelModel::getStationaryFreq, request for non-existent spVec number");
	return _spVec[spVecNumber]->freq(letter) ;
}

MDOUBLE dirSelModel::compLogLikelihood(const tree &et, const sequenceContainer &sc,const VVVdouble &initFreqs) {


	return likelihoodComputationSPvecNonStationary::getTreeLikelihood(et,sc,_spVec,_spVecDistr,initFreqs);

}


void dirSelModel::optimizeParameters(tree& et, const sequenceContainer& sc,const VVVdouble &initFreqs,
									  dirSelOptions* pOptions)
{

	_bestL = compLogLikelihood(et,sc, initFreqs);
	LOGnOUT(5,<<"likelihood with initial parameters values = "<<_bestL<<endl);

	bool allFixed = false;
	if ((pOptions->_fixedS) && (pOptions->_fixedProbS) && (pOptions->_fixedKappa) && (!pOptions->_bblOpt) && (pOptions->_fixedAlpha) && (pOptions->_fixedBeta) && (pOptions->_fixedQ) && (pOptions->_fixedTau))
		allFixed=true;
	if (!allFixed) {

		_lowerBoundParams = 1E-6;
		_upperBoundKappa = 25;
		_upperBoundAlpha = 5;
		_lowerBoundS = pOptions->_lowerBoundS;
		if (_lowerBoundS > _bestS)
			_bestS = _lowerBoundS;
		_upperBoundS = 15;
		_lowerBoundProbS = 0.0;
		_upperBoundProbS = 1.0;

		_lowerBoundBeta = 0.0;
		_upperBoundBeta = 1.0;

		_lowerBoundTau = 0.1;
		_upperBoundTau = 3.0;

		_upperBoundBL = 3;

		LOG(5,<<"Likelihood initialized at = "<<_bestL<<endl);

		LOGnOUT(5,<<"Parameters initialized to:"<<endl);
		LOGnOUT(5,<<"S = "<<pOptions->_initS<<endl);
		LOGnOUT(5,<<"prob(S) = "<<pOptions->_initProbS<<endl);
		LOGnOUT(5,<<"alpha = "<<pOptions->_initAlpha<<endl);
		if (pOptions->_modelName == my_enums::hky) {
			LOGnOUT(5,<<"Kappa = "<<pOptions->_initKappa<<endl);
		}
		LOGnOUT(5,<<"beta = "<<pOptions->_initBeta<<endl);
		LOGnOUT(5,<<"tau = "<<pOptions->_initTau<<endl);
		LOGnOUT(5,<<"q = "<<pOptions->_initQ<<endl);
		if (pOptions->_optimizeLineSearch)
			optimizeParametersLineSearch(et,sc,initFreqs,pOptions);
		else {
			optimizeParametersBrent(et,sc,initFreqs,pOptions);
		}
	}

}

void dirSelModel::optimizeParametersBrent(tree& et, const sequenceContainer& sc,const VVVdouble &initFreqs,
									  dirSelOptions* pOptions)
{
	_epsilonForBrent = 0.1;
	_epsilonLikelihood = 0.1;
	int maxTotalIterations = 20;

	userDistribution *spVecDistr =
		static_cast<userDistribution*>(_spVecDistr);
	bool changed = false;
	int iter=0;

	for (iter=0; iter < maxTotalIterations; ++iter) {
		bool isOneParamChanged=false;
		LOG(5,<<"ITERATION "<<iter<<endl);
		if (!pOptions->_fixedTau && iter==0) {
			LOG(5,<<"Optimizing tau: "<<endl);
					optimizeSpecificParameterBrent(et,sc,initFreqs,pOptions,spVecDistr,
							_bestTau,_lowerBoundTau, _upperBoundTau, my_enums::tau, changed);
			if (changed) {
				isOneParamChanged=true;
				et.multipleAllBranchesByFactor(_bestTau);
			}
			else {
				if (pOptions->_initTau!=1)
					et.multipleAllBranchesByFactor(pOptions->_initTau);
			}
		}
		if (!pOptions->_fixedProbS) {
			LOG(5,<<"Optimizing prob(S): "<<endl);
					optimizeSpecificParameterBrent(et,sc,initFreqs,pOptions,spVecDistr, _bestProbS,_lowerBoundProbS, _upperBoundProbS, my_enums::probS, changed);
					if (changed) isOneParamChanged=true;
				}
		if (!pOptions->_fixedQ) {
			LOG(5,<<"Optimizing q: "<<endl);
					optimizeSpecificParameterBrent(et,sc,initFreqs,pOptions,spVecDistr, _bestQ,_lowerBoundProbS, _upperBoundProbS, my_enums::q, changed);
					if (changed) isOneParamChanged=true;
				}
		if (!pOptions->_fixedS && _bestProbS > _epsilonForBrent) { // no need to optimize S if prob(s)=0
			LOG(5,<<"Optimizing S: "<<endl);
			optimizeSpecificParameterBrent(et,sc,initFreqs,pOptions,spVecDistr, _bestS,_lowerBoundS, _upperBoundS, my_enums::S, changed);
			if (changed) isOneParamChanged=true;
		}
		if (!pOptions->_fixedSout && !pOptions->_isSinSameAsSout && _bestProbS > _epsilonForBrent) { // no need to optimize Sout if prob(s)=0
			LOG(5,<<"Optimizing S-out: "<<endl);
			optimizeSpecificParameterBrent(et,sc,initFreqs,pOptions,spVecDistr, _bestSout,_lowerBoundS,
					_upperBoundS, my_enums::Sout, changed);
			if (changed) isOneParamChanged=true;
		}
		if (!pOptions->_fixedBeta) {
			LOG(5,<<"Optimizing beta: "<<endl);
					optimizeSpecificParameterBrent(et,sc,initFreqs,pOptions,spVecDistr, _bestBeta,_lowerBoundBeta, _upperBoundBeta, my_enums::beta, changed);
					if (changed) isOneParamChanged=true;
		}

		if (!pOptions->_fixedAlpha) {
			LOG(5,<<"Optimizing alpha: "<<endl);
					optimizeSpecificParameterBrent(et,sc,initFreqs,pOptions,spVecDistr, _bestAlpha,_lowerBoundParams, _upperBoundAlpha, my_enums::alpha, changed);
					if (changed) isOneParamChanged=true;
				}
		if (!pOptions->_fixedKappa) {
			LOG(5,<<"Optimizing kappa: "<<endl);
					optimizeSpecificParameterBrent(et,sc,initFreqs,pOptions,spVecDistr, _bestKappa,_lowerBoundParams, _upperBoundKappa, my_enums::kappa, changed);
					if (changed) isOneParamChanged=true;
				}

		if (isOneParamChanged==false) { // only if all params did not change is this value false
			break;
		}
	}

	LOGnOUT(5,<<"---Optimization finished after "<<iter+1<<" iterations, likelihood is "<<_bestL<<endl);
	if (iter== maxTotalIterations) {
		LOGnOUT(5,<<"WARNING!This was the maximal number of iterations. Last values used for further calculations"<<endl);
	}
}

void dirSelModel::optimizeSpecificParameterBrent(tree& et, const sequenceContainer& sc,const VVVdouble &initFreqs,
									  dirSelOptions* pOptions, userDistribution *spVecDistr , MDOUBLE &bestVal,
									  MDOUBLE lowerBound, MDOUBLE upperBound, my_enums::paramName optParamName, bool &changed)
{
	suffStatGlobalGamSpVec *ssc = NULL;
	if (optParamName == my_enums::probS || optParamName == my_enums::q) {
		computePijGamSpVec pi;
		pi.fillPij(et,_spVec);


		ssc = new suffStatGlobalGamSpVec;
		computeUpAlg cup;
		cup.fillComputeUp(et,sc,pi,*ssc);
	}
	MDOUBLE newL = -brent(lowerBound, bestVal, upperBound,
			evalParamsOfdirSelForBrent(et,sc,_spVec,initFreqs,*spVecDistr, pOptions->_modelName,optParamName,
							ssc),
		_epsilonForBrent,&bestVal);
	setBestParamVal(optParamName); // set parameter in this model to best found by brent
	if (newL > _bestL + _epsilonLikelihood) {
		changed = true;
		_bestL = newL;
		LOG(5,<<"new L after optimization of "<<getParamName(optParamName)<<": " <<_bestL<<endl);
		LOG(5,<<"Param "<<getParamName(optParamName)<<" changed to " <<bestVal<<endl<<endl);
	}
	else {
		changed = false; // BUT - value is still saved
		LOG(5,<<"new L after optimization of "<<getParamName(optParamName)<<" rejected: " <<_bestL<<endl);
		LOG(5,<<"Param "<<getParamName(optParamName)<<" rejected with value " <<bestVal<<endl<<endl);


	}
	if (ssc)
		delete ssc;
}


void dirSelModel::setBestParamVal(my_enums::paramName paramName) {
	switch (paramName){
		case my_enums::S: {
			int alphSize = _spVec[0]->alphabetSize();
			for (int i = 0; i< alphSize; ++i){
				static_cast<replacementModeldirSel*>(_spVec[i]->getPijAccelerator()->getReplacementModel())->setS(_bestS);
			}
			break;
		}
		case my_enums::probS: {
			int alphabetSize = _spVec[0]->alphabetSize();
			MDOUBLE oldP = _spVecDistr->ratesProb(0) * alphabetSize;
			Vdouble newProbs(_spVec.size(),0.0);

			for (int i=0; i<alphabetSize; ++i) // multiply only change selection categories (first alph ceatgories)
				 newProbs[i] = (_bestProbS/alphabetSize);

			if (oldP==1.0) {
				MDOUBLE newValProb = (1.0-_bestProbS) / (alphabetSize+1);
				for (int j=alphabetSize; j<newProbs.size(); ++j) {// correct all the rest of the probs
					newProbs[j] = newValProb;
				}
			}
			else {
				MDOUBLE factor = (1.0-_bestProbS)/(1.0 - oldP);
				for (int j=alphabetSize; j<newProbs.size(); ++j) {// correct all the rest of the probs
					newProbs[j] = _spVecDistr->ratesProb(j) * factor;

				}
			}
			MDOUBLE sum = 0.0;
			for (int k=0; k<newProbs.size(); ++k) {
				sum+=newProbs[k] ;
			}
			if (abs(sum-1.0)> 0.000001 )
				errorMsg::reportError("evalParamsOfdirSelForBrent::updateProbS: sum of probs is not 1");

			static_cast<userDistribution*>(_spVecDistr)->resetProbs(newProbs);
			break;
		}
		case my_enums::alpha: {
			for (int i = 0; i< _spVec.size(); ++i){ // update alpha in all models
				static_cast<gammaDistribution*>(_spVec[i]->distr())->setAlpha(_bestAlpha);
			}
			break;
		}
		case my_enums::kappa: {
			// update the base fifth model
			hky *base_model = static_cast<hky*>(_spVec[_spVec.size()-1]->getPijAccelerator()->getReplacementModel());
			base_model->changeTrTv(_bestKappa);

			for (int i = 0; i< _spVec.size()-1; ++i){ // update kappa in all 4 dirSel models
				replacementModeldirSel* pRM = static_cast<replacementModeldirSel*>(_spVec[i]->getPijAccelerator()->getReplacementModel());
				pRM->updateBaseReplacementModel(base_model);
			}

			break;
		}
		case my_enums::beta: {
			for (int i = 0; i< _spVec.size(); ++i){ // update  in all models
				_spVec[i]->setRelaxationFactor(_bestBeta);
			}
			break;
		}
		case my_enums::tau:
			// do nothing
			break;
		case my_enums::q:
			// for now do nothing!!!!!!!
			break;
		case my_enums::Sout: {
			int alphSize = _spVec[0]->alphabetSize();
			for (int i = 0; i< alphSize; ++i){
				static_cast<replacementModeldirSel*>(_spVec[i]->getPijAccelerator()->getReplacementModel())->setSout(_bestProbS);
			}
			break;
		}
		default:
			errorMsg::reportError("dirSelModel::revertToOldParamVal, illegal parameter name");
			break;
	}
}



void dirSelModel::optimizeParametersLineSearch(tree& et, const sequenceContainer& sc,const VVVdouble &initFreqs,
									  dirSelOptions* pOptions)
{
	userDistribution *spVecDistr =
		static_cast<userDistribution*>(_spVecDistr);
	//evalBLsOfdirSel eb (et,sc,_spVec,_initFreqs,spVecDistr);
	// get a vector of all current branch lengths, ordered top-down

	Vdouble params;

	Vdouble lower_bounds;
	Vdouble upper_bounds;
	if (pOptions->_bblOpt) {
		getBLs(et,params);
		for (int i=0; i<params.size(); ++i) {
			lower_bounds.push_back(_lowerBoundParams);
			upper_bounds.push_back(_upperBoundBL);
		}
	}

	if (!pOptions->_fixedS) {
	// param and bound on S
		params.push_back(pOptions->_initS);
		lower_bounds.push_back(_lowerBoundS);
		upper_bounds.push_back(_upperBoundS); // upper bound on S
	}
	if (!pOptions->_fixedProbS){
	// param and bound on probS
		params.push_back(pOptions->_initProbS);
		lower_bounds.push_back(_lowerBoundProbS);
		upper_bounds.push_back(_upperBoundProbS);

	}
	if (!pOptions->_fixedAlpha ) {
		// param and bounds on alpha
		params.push_back(pOptions->_initAlpha);
		lower_bounds.push_back(_lowerBoundParams);
		upper_bounds.push_back(_upperBoundAlpha); // upper bound on alpha
	}
	if ((!pOptions->_fixedKappa) && (pOptions->_modelName == my_enums::hky)) {
		params.push_back(pOptions->_initKappa);
		lower_bounds.push_back(_lowerBoundParams);
		upper_bounds.push_back(_upperBoundKappa);
	}
	if (!pOptions->_fixedBeta) {
		params.push_back(pOptions->_initBeta);
		lower_bounds.push_back(_lowerBoundBeta);
		upper_bounds.push_back(_upperBoundBeta);
	}
	if (!pOptions->_fixedTau) {
		params.push_back(pOptions->_initTau);
		lower_bounds.push_back(_lowerBoundTau);
		upper_bounds.push_back(_upperBoundTau);
	}
	if (!pOptions->_fixedQ) {
		params.push_back(pOptions->_initQ);
		lower_bounds.push_back(_lowerBoundProbS);
		upper_bounds.push_back(_upperBoundProbS);
	}
	double* init_params = &params[0];
	double *low = &lower_bounds[0];
	double *up = &upper_bounds[0];
	Vint number_of_bounds (params.size(),2);
	int *nbd=&number_of_bounds[0];
	LOGnOUT(5,<<"Running optimization, number of parameters to optimize = "<<params.size()<<endl);
	_bestL= findmax_bfgs(params.size(),init_params,NULL,
			evalAllParamsOfdirSel(et,sc,_spVec,initFreqs,*spVecDistr, pOptions->_modelName,
					pOptions->_bblOpt,pOptions->_fixedS,pOptions->_fixedProbS,pOptions->_fixedAlpha,pOptions->_fixedKappa,
					pOptions->_fixedBeta, pOptions->_fixedTau, pOptions->_fixedQ  , _bestTau),
			NULL,low,up,nbd, 30);
	LOGnOUT(5,<<endl<<"Finished optimization of parameters for this round with likelihood "<<_bestL<<endl<<endl);
	cout<<"final parameters now in members are"<<endl;
	_bestProbS = spVecDistr->ratesProb(0)*20;
	cout<<"prob(S)="<<_bestProbS<<endl;
	replacementModeldirSel* pRM = static_cast<replacementModeldirSel*>(_spVec[0]->getPijAccelerator()->getReplacementModel());
	_bestS = pRM->getS();
	cout<<"S="<<_bestS<<endl;
	_bestAlpha = static_cast<gammaDistribution*>(_spVec[0]->distr())->getAlpha();
	_bestBeta = _spVec[0]->getRelaxationFactor();
	if (pOptions->_modelName == my_enums::hky) {
		hky *base_model = static_cast<hky*>(_spVec[_spVec.size()-1]->getPijAccelerator()->getReplacementModel());
		_bestKappa = base_model->getTrTv();
	}
	if (_bestTau!=1.0)
		et.multipleAllBranchesByFactor(_bestTau);
	cout<<"tau="<<_bestTau<<endl;
	cout<<"q="<<_bestQ<<endl;

}



// returns branch lengths ordered by iterator; skips root
void dirSelModel::getBLs(const tree &et,Vdouble &BLs) {
	treeIterTopDownConst tIt(et);
	for (tree::nodeP mynode = tIt.first(); mynode != tIt.end(); mynode = tIt.next()) {
		if (mynode->isRoot()) {
			continue;
		}
		BLs.push_back(mynode->dis2father());
	}

}

void dirSelModel::fillSuffStatGlobalGam(suffStatGlobalGam &ssc, const tree &et,
													  const sequenceContainer &sc)
{
	computePijGam pi;
	pi._V.resize(_spVec.size());
	for (int i=0; i < _spVec.size(); ++i) {
		pi._V[i].fillPij(et,*_spVec[i]);
	}
	computeUpAlg cup;
	cup.fillComputeUp(et,sc,pi,ssc);
}


void dirSelModel::printModelParam(ofstream& outFile,dirSelOptions* pOptions) const
{

	outFile<<"#dirSel Results File";
	outFile<<endl;
	outFile<<"#============================================================"<<endl;
	outFile<<"#Parameters are:"<<endl;
	outFile<<"#Log-likelihood: "<<_bestL<<endl<<
		"#S= "<<_bestS<<endl<<
		"#Prob (S)= "<<(pOptions->_selectionAgainstChar ? "(negative) " : "")<<_bestProbS<< endl<<
		"#alpha="<<_bestAlpha<<endl;
	if (pOptions->_modelName == my_enums::hky) {
		outFile<<"#K="<<_bestKappa<<endl;
	}
	outFile<<"#beta="<<_bestBeta<<endl;
	outFile<<"#tau="<<_bestTau<<endl;
	outFile<<"#q="<<_bestQ<<endl;

	outFile<<"#Rate categories are "<<endl;
	for (int i=0; i<_spVec[0]->distr()->categories(); ++i)
		outFile<<"#\t"<<_spVec[0]->rates(i)<<endl;
}

string dirSelModel::getParamName(my_enums::paramName type) {
	string res = "";
	switch (type)
	{
	case my_enums::S:
		res = "S";
		break;
	case my_enums::probS:
		res = "prob(S)";
		break;
	case my_enums::alpha:
		res = "alpha";
		break;
	case my_enums::kappa:
		res = "kappa";
		break;
	case my_enums::beta:
		res = "beta";
		break;
	case my_enums::tau:
		res = "tau";
		break;
	case my_enums::q:
		res = "q";
		break;
	case my_enums::Sout:
		res = "S-out";
		break;
	default:
		errorMsg::reportError("ERROR in dirSelModel::getParamName : unknown type");
	}
	return res;
}
