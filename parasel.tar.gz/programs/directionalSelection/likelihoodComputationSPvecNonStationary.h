// $Id: likelihoodComputationSPvec.h 950 2006-10-19 12:12:34Z eyalprivman $

#ifndef ___LIKELIHOOD_COMPUTATION_SPVEC_NON_STATIONARY
#define ___LIKELIHOOD_COMPUTATION_SPVEC_NON_STATIONARY

#include "definitions.h"
#include "computePijComponent.h"
#include "sequenceContainer.h"
#include "suffStatComponent.h"

namespace likelihoodComputationSPvecNonStationary {

	MDOUBLE getTreeLikelihood(const tree& et,
							const sequenceContainer& sc,
							const vector<stochasticProcess*>& spVec,  
							const distribution * spVecDistr, const VVVdouble &initFreqs);

	MDOUBLE getTreeLikelihoodUpIsFilled(const tree& et,
		const sequenceContainer& sc,
		const suffStatGlobalGamSpVec& ssc,const distribution * spVecDistr, const distribution *rateDistr, const VVVdouble &initFreqs);

	MDOUBLE getProbOfPosUpIsFilledSelectionGam(const int pos,const tree& et, //used for one position
						const sequenceContainer& sc,
						const suffStatGlobalGamSpVecPos& cup,
						const distribution * spVecDistr, const distribution *rateDistr, const VVdouble &initFreqsForPos);

	MDOUBLE getLofPosGivenSpVecCategor(const int pos,
						  const tree& et,
						  const sequenceContainer& sc,const distribution *rateDistr,
						  const suffStatGlobalGamPos& ssc,Vdouble &initFreqForPosAndSp);



/*	MDOUBLE getTreeLikelihoodFromUp2(const tree& et,
							const sequenceContainer& sc,
							const stochasticProcess& sp,
							const suffStatGlobalGam& cup,
							Vdouble& posLike, // fill this vector with each position likelihood but without the weights.
							const distribution * distr,
							const VVdouble &initFreqs,
							const Vdouble * weights=0);
							*/



};



#endif
