#ifndef __NODE_DATA
#define __NODE_DATA

#include <iostream>
#include <algorithm>
#include "definitions.h"
#include "someUtil.h"
#include "posSdata.h"


class nodePosData {
public:
	nodePosData() {}
	nodePosData(int nodeId, int posNumberInRefseq, int startLetter, int endLetter, MDOUBLE posteriorProb) :
		_nodeId(nodeId), _posNumberInRefseq(posNumberInRefseq), _startLetter(startLetter), _endLetter(endLetter), _posteriorProb(posteriorProb){}
	int getPosNumber() {return _posNumberInRefseq;}
	string getMutation () {return (int2string(_startLetter) + "->" + int2string(_endLetter));}

private:
	int _nodeId;

	int _posNumberInRefseq;
	int _startLetter;
	int _endLetter;
	MDOUBLE _posteriorProb;

};

class nodeData {
public:
	nodeData() {};
	nodeData(int nodeId) ;
	void setInfo(int nodeId, string nodeName, MDOUBLE dis2father) {_nodeId=nodeId;_nodeName=nodeName; _dis2father=dis2father;}
	void addPosition(int newPosition, int startLetter, int endLetter, MDOUBLE posterior) ;

	string data2print () ;
	int getNodeId() const {return _nodeId;}

private:
	int _nodeId;
	string _nodeName;
	MDOUBLE _dis2father;
	vector<nodePosData> _positions;


};


#endif // __NODE_DATA
