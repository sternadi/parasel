/********************************************************************************************
dirSelOptions - a class that contains all the parameters.
	use the 'Parameters' class to read info from txt file.
	initDefault. (+Parameters::addParameter)
	getParamsFromFile. ->with alterations of defults for consistancy
	verifyConsistParams.
*********************************************************************************************/
#include "dirSelOptions.h"
#include "errorMsg.h"
#include "someUtil.h"
#include "Parameters.h"
#include <iostream>
#include <cmath>

using namespace std;

dirSelOptions::~dirSelOptions(){}
/********************************************************************************************
*********************************************************************************************/
void dirSelOptions::initOptions(const string& paramFileName)
{	
	initDefault();
	getParamsFromFile(paramFileName);
	verifyConsistParams();
}

/********************************************************************************************
initDefault
*********************************************************************************************/
void dirSelOptions::initDefault()
{
// all the default values are stored in the dirSelOptions:: static members
//################### Basic parameters:
// input (general)
    _inSeqFile = "";
    _inTreeFile = "";
	_inQuerySeq = "";

// output
	_logFile = "dirSel.log";
	 _verboseLevel = 5;
    _outTreeFile = "dirSel.tree";
    _outResFile = "dirSel.res";

//################################################## Model params
    _fixedS = false;
    _initS = 10;
    _fixedProbS = false;
    _initProbS = 0.01;

    _alphabetSize = 4; //default is nucleotide
    _modelName = my_enums::hky;
    _initKappa = 2;
    _fixedKappa=false;

    _initAlpha = 1.0;
    _fixedAlpha = false;

    _initBeta = 0.0;
    _fixedBeta = true;

    _initTau = 1.0;
    _fixedTau = true;

    _initQ = 0;
    _fixedQ = true;

    _lowerBoundS = 0.001;


    _bblOpt = false; // by default do not perform BBL optimization
    _isNull = false; // not null model
    _useQueryFreqsAtRoot = false; // by default use stationary probabilities at the root
    _optimizeLineSearch = false;
    _threshold = 0.75;
    _doMutationMapping = false;

    _useS0AtRoot =true;
    _rootAt = "";


    _isSinSameAsSout = true;
    _fixedSout = true;
    _initSout = _initS;

    _selectionAgainstChar = false;

// all the parameters are added to the static: ParamList paramList (vector<Parameter>);	
	Parameters::addParameter("_inSeqFile", _inSeqFile);
	Parameters::addParameter("_inTreeFile", _inTreeFile);
	Parameters::addParameter("_inQuerySeq", _inQuerySeq);
	Parameters::addParameter("_logFile", _logFile);
	Parameters::addParameter("_verboseLevel", _verboseLevel);
	Parameters::addParameter("_outTreeFile", _outTreeFile);

	Parameters::addParameter("_fixedS", _fixedS);
	Parameters::addParameter("_initS", _initS);
	Parameters::addParameter("_fixedProbS", _fixedProbS);
	Parameters::addParameter("_initProbS", _initProbS);
	Parameters::addParameter("_initKappa", _initKappa);
	Parameters::addParameter("_fixedKappa", _fixedKappa);
	Parameters::addParameter("_initAlpha", _initAlpha);
	Parameters::addParameter("_fixedAlpha", _fixedAlpha);
	Parameters::addParameter("_initBeta", _initBeta);
	Parameters::addParameter("_fixedBeta", _fixedBeta);

	Parameters::addParameter("_initTau", _initTau);
	Parameters::addParameter("_fixedTau", _fixedTau);

	Parameters::addParameter("_initQ", _initQ);
	Parameters::addParameter("_fixedQ", _fixedQ);

	Parameters::addParameter("_lowerBoundS", _lowerBoundS);

	Parameters::addParameter("_alphabetSize", _alphabetSize);
	Parameters::addParameter("_modelName", getModelNameType(_modelName));
	Parameters::addParameter("_bblOpt", _bblOpt);
	Parameters::addParameter("_isNull", _isNull);
	Parameters::addParameter("_useQueryFreqsAtRoot", _useQueryFreqsAtRoot);
	Parameters::addParameter("_optimizeLineSearch", _optimizeLineSearch);
	Parameters::addParameter("_threshold", _threshold);
	Parameters::addParameter("_doMutationMapping", _doMutationMapping);
	Parameters::addParameter("_useS0AtRoot", _useS0AtRoot);
	Parameters::addParameter("_rootAt", _rootAt);

	Parameters::addParameter("_isSinSameAsSout", _isSinSameAsSout);
	Parameters::addParameter("_fixedSout", _fixedSout);
	Parameters::addParameter("_initSout", _initSout);
	Parameters::addParameter("_selectionAgainstChar", _selectionAgainstChar);

}
/********************************************************************************************
readParameters
*********************************************************************************************/
void dirSelOptions::readParameters(const string& paramFileName)
{
	ifstream params(paramFileName.c_str());
	if(params.good())
		Parameters::readParameters(params);		// only place where params are read, updateParameter(paramName, param.c_str()) used
	params.close();
}

/********************************************************************************************
getParamsFromFile
*********************************************************************************************/
void dirSelOptions::getParamsFromFile(const string& paramFileName)
{	
	readParameters(paramFileName);
	_inSeqFile = Parameters::getString("_inSeqFile");
	_inTreeFile = Parameters::getString("_inTreeFile");
	_inQuerySeq = Parameters::getString("_inQuerySeq");
	
	_logFile = Parameters::getString("_logFile");
	_verboseLevel = Parameters::getInt("_verboseLevel");
	_outTreeFile = Parameters::getString("_outTreeFile");
	_outResFile = Parameters::getString("_outResFile");

	_isNull = (Parameters::getInt("_isNull") == 1) ? true : false;
	if (_isNull) {
		_initProbS = 0.0;
		_fixedProbS = true;
		_initS = 0.001;
		_fixedS = true;
	}
	else {
		_initProbS = Parameters::getFloat("_initProbS");
		_fixedProbS = (Parameters::getInt("_fixedProbS") == 1) ? true : false;
		_fixedS = (Parameters::getInt("_fixedS") == 1) ? true : false;
		_initS = Parameters::getFloat("_initS");

	}

	_fixedAlpha = (Parameters::getInt("_fixedAlpha") == 1) ? true : false;
	_initAlpha = Parameters::getFloat("_initAlpha");

	_initKappa = Parameters::getFloat("_initKappa");
	_fixedKappa = (Parameters::getInt("_fixedKappa") == 1) ? true : false;

	_fixedBeta = (Parameters::getInt("_fixedBeta") == 1) ? true : false;
	_initBeta = Parameters::getFloat("_initBeta");

	_fixedTau = (Parameters::getInt("_fixedTau") == 1) ? true : false;
	_initTau = Parameters::getFloat("_initTau");

	_fixedQ = (Parameters::getInt("_fixedQ") == 1) ? true : false;
	_initQ = Parameters::getFloat("_initQ");

	_lowerBoundS = Parameters::getFloat("_lowerBoundS");

	_isSinSameAsSout = (Parameters::getInt("_isSinSameAsSout") == 1) ? true : false;
	_fixedSout = (Parameters::getInt("_fixedSout") == 1) ? true : false;
	_initSout = Parameters::getFloat("_initSout");

	_modelName = getModelNameType(Parameters::getString("_modelName"));
	switch (_modelName) {
		case (my_enums::jtt):
			_alphabetSize = 20;
			break;
		case (my_enums::rev):
			_alphabetSize = 20;
			break;
		case (my_enums::day):
				_alphabetSize = 20;
				break;
		case (my_enums::aajc):
				_alphabetSize = 20;
				break;
		case (my_enums::HIVb):
				_alphabetSize = 20;
				break;
		case (my_enums::HIVw):
				_alphabetSize = 20;
				break;
		case (my_enums::hky):
			_alphabetSize = 4;
			break;
		default: errorMsg::reportError("dirSelOptions::getParamsFromFile: modelName is not supported");
		}

	_bblOpt = (Parameters::getInt("_bblOpt") == 1) ? true : false;

	_useQueryFreqsAtRoot = (Parameters::getInt("_useQueryFreqsAtRoot") == 1) ? true : false;
	_optimizeLineSearch = (Parameters::getInt("_optimizeLineSearch") == 1) ? true : false;
	_threshold = Parameters::getFloat("_threshold");
	_doMutationMapping = (Parameters::getInt("_doMutationMapping") == 1) ? true : false;
	_useS0AtRoot = (Parameters::getInt("_useS0AtRoot") == 1) ? true : false;
	_rootAt = Parameters::getString("_rootAt");
	_selectionAgainstChar = (Parameters::getInt("_selectionAgainstChar") == 1) ? true : false;
}


/********************************************************************************************
*********************************************************************************************/
void dirSelOptions::verifyConsistParams()
{
	if (_inSeqFile.size() == 0)	{
		errorMsg::reportError("The input sequence file is missing");
	}
	if (_inTreeFile.size() == 0)	{
		errorMsg::reportError("The input tree file is missing");
	}
	if (_modelName != my_enums::hky)
		_fixedKappa = true; // this is just to prevent optimization
	if ((_isNull) && (!_fixedProbS && _initProbS > 0.0))
			errorMsg::reportError("Null model invoked but prob(S)>0 or _fixedProbS=false");
	if (_optimizeLineSearch == false && _bblOpt == true) {
		errorMsg::reportError("branch length optimization currently not supported with optimization with brent ");
	}
	if (_bblOpt && !_fixedTau)
		errorMsg::reportError("when branch length optimization performed scaling factor for tree not necessary ");
	if (_useQueryFreqsAtRoot) {
		if (_rootAt == "") {
			_rootAt = _inQuerySeq;
		}
		if (_rootAt != _inQuerySeq) {
			errorMsg::reportError("when frequencies are used from the query sequence, the root cannot be different from the query sequence ");
		}
	}
	else {
		if (_doMutationMapping) {
			errorMsg::reportError("Mutation mapping is not supported unless a root sequence is specified (invoke _rootAt, _inQuerySeq, and _useQueryFreqsAtRoot)");
		}
	}
	if (_initQ!=0) {
		if (_initQ + _initProbS >1)
			errorMsg::reportError("initial values of P and Q exceed 1 ");
	}
	if (!_fixedQ && _optimizeLineSearch)
		errorMsg::reportError("q model not currently supported with line search (bfgs) ");
	if (_isSinSameAsSout && !_fixedSout) {
		errorMsg::reportError("S_in==Sout, param S_out cannot be optimized (was not fixed)");
	}
	if (_optimizeLineSearch == true && _doMutationMapping == true) {
		errorMsg::reportError("Currently mutation mapping is only supported together with optimization with brent. Set _optimizeLineSearch to zero.");
	}


}

/********************************************************************************************
*********************************************************************************************/

void dirSelOptions::printOptionParameters() {
	LOGnOUT(5,<<"\n ---------------------- THE PARAMETERS FOR THE RUN------------------------"<<endl);
	LOGnOUT(5,<<"input alignment file is:    "<<_inSeqFile <<endl);

	LOGnOUT(5,<<"input tree file is:             "<<_inTreeFile <<endl);
	LOGnOUT(5,<<"base model name is:             "<< getModelNameType(_modelName)<<endl);
	LOGnOUT(5,<<"Use stationary probabilities at root (alternative is query sequence indicator function):      "<< (_useQueryFreqsAtRoot?"no":"yes")<<endl);
	if (!_useQueryFreqsAtRoot)
		LOGnOUT(5,<<"Distribution used at root for selection models:     "<<(_useS0AtRoot?"null model(S=0)":"stationary for S models")<<endl);
	LOGnOUT(5,<<"optimizer is:     "<<(_optimizeLineSearch?"line search (BFGS-L)":"brent")<<endl);
	LOGnOUT(5,<<"is this a null model run?:     "<<(_isNull?"yes":"no")<<endl);
	LOGnOUT(5,<<"optimize branch lengths?:     "<<(_bblOpt?"yes":"no")<<endl);
	LOGnOUT(5,<<"perform mutation mapping?:     "<<(_doMutationMapping?"yes":"no")<<endl);
	if (!_isNull) {
		LOGnOUT(5,<<"initial S :     "<<_initS<<endl);

		LOGnOUT(5,<<"optimize S:     "<<(_fixedS?"don't do":"do")<<endl);
		LOGnOUT(5,<<"lower bound on S :     "<<_lowerBoundS<<endl);

		LOGnOUT(5,<<"initial prob(S):     "<<_initProbS<<endl);
		LOGnOUT(5,<<"optimize prob(S):     "<<(_fixedProbS?"don't do":"do")<<endl);
		LOGnOUT(5,<<"selection for or against a character?     "<<(_selectionAgainstChar?"against":"for")<<endl);
	}
	if (_modelName == my_enums::hky) {
		LOGnOUT(5,<<"optimize K:     "<<(_fixedKappa?"don't do":"do")<<endl);
		LOGnOUT(5,<<"initial K :     "<<_initKappa<<endl);
	}
	LOGnOUT(5,<<"initial alpha:     "<<_initAlpha<<endl);
	LOGnOUT(5,<<"optimize alpha:     "<<(_fixedAlpha?"don't do":"do")<<endl);

	LOGnOUT(5,<<"initial q:     "<<_initQ<<endl);
	LOGnOUT(5,<<"optimize q:     "<<(_fixedQ?"don't do":"do")<<endl);

	LOGnOUT(5,<<"initial beta (relaxation factor for leaves):     "<<_initBeta<<endl);
	LOGnOUT(5,<<"optimize beta:     "<<(_fixedBeta?"don't do":"do")<<endl);

	LOGnOUT(5,<<"optimize tau:     "<<(_fixedTau?"don't do":"do")<<endl);
	LOGnOUT(5,<<"initial tau (scaling factor for tree):     "<<_initTau<<endl);


	LOGnOUT(5,<<"output log file is:             "<< _logFile<<endl);

	LOGnOUT(5,<<"output tree file is:            "<<_outTreeFile <<endl);
	LOGnOUT(5,<<"output results file is:  "<<_outResFile <<endl);
	LOGnOUT(5,<<"threshold for printing posterior probabilities of mutation events:  "<<_threshold <<endl);

}


string dirSelOptions::getModelNameType(my_enums::modelNameType type)
{
	string res = "";
	switch (type)
	{
	case my_enums::rev:
		res = "rev";
		break;
	case my_enums::jtt:
		res = "jtt";
		break;
	case my_enums::day:
		res = "day";
		break;
	case my_enums::aajc:
		res = "aajc";
		break;
	case my_enums::hky:
		res = "hky";
		break;
	case my_enums::nucjc:
		res = "nucjc";
		break;
	case my_enums::wag:
		res = "wag";
		break;
	case my_enums::cprev:
		res = "cprev";
		break;
	case my_enums::HIVb:
		res = "HIVb";
		break;
	case my_enums::HIVw:
		res = "HIVw";
		break;
	default:
		errorMsg::reportError("ERROR in dirSelOptions::getModelNameType : unknown model");
	}
	return res;
}

my_enums::modelNameType dirSelOptions::getModelNameType(const string& str)
{
	if (str == "rev")
		return my_enums::rev;
	if (str == "jtt")
		return my_enums::jtt;
	if (str == "day")
		return my_enums::day;
	if (str == "aajc")
		return my_enums::aajc;
	if (str == "hky")
		return my_enums::hky;
	if (str == "nucjc")
		return my_enums::nucjc;
	if (str == "wag")
		return my_enums::wag;
	if (str == "cprev")
		return my_enums::cprev;
	if (str == "HIVb")
		return my_enums::HIVb;
	if (str == "HIVw")
		return my_enums::HIVw;
	else
		errorMsg::reportError("ERROR in dirSelOptions::getModelNameType : unknown type");
	return my_enums::hky;
}

