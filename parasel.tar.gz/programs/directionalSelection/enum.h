/*
 * enum.h
 *
 *  Created on: Aug 1, 2012
 *      Author: adi
 */

#ifndef ENUM_H_
#define ENUM_H_

#include "errorMsg.h"

namespace my_enums
{
	enum modelNameType {rev,jtt,day,aajc,nucjc,hky,wag,cprev,HIVb,HIVw};
	enum paramName {S, probS, alpha, kappa, beta, tau,q, Sout};

}





#endif /* ENUM_H_ */
