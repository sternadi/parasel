#ifndef ___DIRECTIONAL_SELECTION____H
#define ___DIRECTIONAL_SELECTION____H

#include "definitions.h"
#include <time.h>
#include "sequenceContainer.h"
#include "tree.h"
#include "stochasticProcess.h"
#include "logFile.h"
#include "dirSelOptions.h"
#include "suffStatComponent.h"
#include "dirSelModel.h"
#include "posSdata.h"

class directionalSelection {

public:
	explicit directionalSelection(int argc, char* argv[]);
	virtual ~directionalSelection();
public:
	void run(int argc, char** argv);
	void printInfo(ostream& out);
	void fillOptionsParameters(int argc, char** argv);
	void optimizeParams();
private:
	void initScAndTree();
	void fill_initFreqs();
	void createTree();

	MDOUBLE computePosteriorProb4site(const int pos, posData& pos_data);
	void getNodesPosteriorProbs4significantSites();
	void initPositionsData();
	void computePosteriorProbs();
	void site_specific_ML_over_S(int pos, posData& pos_data);
	void printResults();
	void fillPij();
		
private:
	dirSelOptions* _pOptions;
	sequenceContainer *_sc;
	tree _t;
	dirSelModel* _dirSelModel;
	alphabet* _alph;
	sequence* _refSeq;
	VVVdouble _initFreqs;  // [pos][sp][let] initial root freqs may be stationary or an indicator function of the query sequence (which is in theory the root)
							// if stationary, will be redundant over positions; if indicator position will be redundant over sp
	computePijGamSpVec _pij;
	suffStatGlobalGamSpVec _sscUp;

	vector<posData> _positionsData;

};

#endif
