#ifndef ___DIRSEL__OPTIONS_H
#define ___DIRSEL__OPTIONS_H

#include "definitions.h"
#include "enum.h"
#include <string>
#include <fstream>
using namespace std;

/*
--- utilize CLASS:Parameters ---
USAGE: SETTING DEFAULT PARAMETERS
Note that the type of the parameter is set according to the addParameter arguments. 
e.g., If a parameter is set using addParameter with an integer argument then subsequent updates (using updateParameter) 
to the same parameter will all be stored as integers. 
Therefore the following code should output a 0:
EXAMPLE
Parameters::addParameter("Dummy", 3);
Parameters::updateParameter("Dummy", "This should set it to zero");
cout << Parameters::getString("Dummy");
END
Note also that when setting default values of float parameters always use
a decimal point or else these parameters will be added as integers. 

USAGE: READING PARAMETERS FROM FILE
The readParameters method receives an input stream from which parameters are to be read. 
Files are structured so that each line specifies the value of a parameter. 
Each line gives the parameter name, a white space and then the parameter value. 
Lines whose first non white-space charachter is # are ignored. 
A basic schema for using the Parameters class is to set the default
values using addParameter calls and then calling readParameters to read in
parameters with other values or new parameters. 
EXAMPLE
Parameters::addParameter("CubeSize", 1.0);
Parameters::addParameter("MinVote", 8);
ifstream params("params");
Parameters::readParameters(params);
params.close();
Parameters::dump(cout);
END
With the following parameters file:
EXAMPLE
CubeSize 0.5
File  pdb4hhb.ent
END
The following output should result:
EXAMPLE
CubeSize (Float) 0.5
File     (Str)   pdb4hhb.ent
MinVote  (Int)   8
END

USAGE: SUBCLASSING AND PERFORMANCE
The Parameters engine keeps the parameters in a sorted list.
The correct usage would have been to inherit: e.g., class ProgParams : protected Parameters

*/

class dirSelOptions{

public:
	virtual ~dirSelOptions();

	void initOptions(const string& paramFileName);
	void initDefault();
	void readParameters(const string& paramFileName);
	void getParamsFromFile(const string& paramFileName);
	void getOutDirFromFile(const string& paramFileName);
	void verifyConsistParams();
	void printOptionParameters();
	string getModelNameType(my_enums::modelNameType type);
	my_enums::modelNameType getModelNameType(const string& str);


public:
//################### Basic parameters:
// input (general)

    string _inSeqFile;
    string _inTreeFile;
	string _inQuerySeq;

// output
	string _logFile;   
	int _verboseLevel; // verbose log level
    string _outTreeFile;
    string _outResFile; //file with posterior values for site
	string _outNodesResFile;
  
//################################################## Model params    


	bool _fixedS;
    MDOUBLE _initS;// initial  S
    bool _fixedProbS;
    MDOUBLE _initProbS; // P - probability of selection change (from root along tree)
    MDOUBLE _initKappa; // if hky
    bool _fixedKappa;
    MDOUBLE _initAlpha;
    bool _fixedAlpha;
    MDOUBLE _initBeta; //relaxation factor for leaves
    bool _fixedBeta;

    bool _fixedQ; //q - probability of selection constant along the tree
    MDOUBLE _initQ;

    MDOUBLE _initTau; //scaling factor for tree
    bool _fixedTau;

    MDOUBLE _lowerBoundS;

    bool _useS0AtRoot; // defines stationary frequencies used by the selection models: true means use null stationary at root; false means use real stationary frequencies of selection model
    string _rootAt; // node name to root at

    bool _isSinSameAsSout;
	bool _fixedSout;
    MDOUBLE _initSout;// initial  S

    bool _selectionAgainstChar; // default-false, selection for a certain char. alternative - true, selection is against a certain char

    int _alphabetSize;
    my_enums::modelNameType _modelName; // base model used for further expansion
    bool _bblOpt; //true if branch lengths are to be optimized
    bool _isNull;

    bool _useQueryFreqsAtRoot;
    bool _optimizeLineSearch;


    MDOUBLE _threshold; // posterior probability threshold to calculate site specific S values; default 0.95
    bool _doMutationMapping; // map mutations along the tree


};
#endif
