// $Id: fromCountTableComponentToDistanceSPvec.cpp 950 2006-10-19 12:12:34Z eyalprivman $

#include "fromCountTableComponentToDistanceSPvec.h"
#include "likeDistSPvec.h"
#include "likeDist.h"
#include <cassert>

fromCountTableComponentToDistanceSPvec::fromCountTableComponentToDistanceSPvec(
		const countTableComponentGam& ctc,
		const vector<stochasticProcess*> &spVec,
		const distribution *distr,
		const MDOUBLE toll,
		const MDOUBLE brLenIntialGuess ) :  _ctc(ctc) {
	_distance = brLenIntialGuess ;//0.03;
	_toll = toll;
	_distr = distr->clone();
	_spVec.resize(spVec.size());
	for (int i = 0; i< spVec.size(); ++i)
		_spVec[i] = spVec[i]->clone();
}

fromCountTableComponentToDistanceSPvec::fromCountTableComponentToDistanceSPvec 
(const fromCountTableComponentToDistanceSPvec& other): _ctc(other._ctc), _toll(other._toll), _distance(other._distance),
_likeDistance(other._likeDistance)
{
	_distr = other._distr->clone();
	_spVec.resize(other._spVec.size());
	for (int i = 0; i< other._spVec.size(); ++i)
	_spVec[i] = other._spVec[i]->clone();

}


fromCountTableComponentToDistanceSPvec::~fromCountTableComponentToDistanceSPvec(){

    if (_distr)
		delete _distr;
	for (int i = 0; i< _spVec.size(); ++i){
		if (_spVec[i]) delete _spVec[i];
	}
}

void fromCountTableComponentToDistanceSPvec::computeDistance() {
	likeDistSPvec likeDist1(_spVec,_distr,_toll);
	MDOUBLE initGuess = _distance;
	_distance = likeDist1.giveDistance(_ctc,_likeDistance,initGuess);
	assert(_distance>=0);
}
