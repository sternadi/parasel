// $Id: replacementModel.cpp 962 2006-11-07 15:13:34Z privmane $

#include "replacementModel.h"

replacementModel::~replacementModel(){}
// this must be here. see Effective c++ page 63 (item 14, constructors, destructors, 
// assignment


