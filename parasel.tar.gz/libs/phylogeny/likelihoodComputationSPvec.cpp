#include "likelihoodComputationSPvec.h"

#include "definitions.h"
#include "tree.h"
#include "computeUpAlg.h"
#include "likelihoodComputation.h"

#include <cmath>
#include <cassert>

using namespace likelihoodComputationSPvec;



MDOUBLE likelihoodComputationSPvec::getTreeLikelihoodAllPosAlphTheSame(const tree& et,
							const sequenceContainer& sc,
							const vector<stochasticProcess*>& spVec,const distribution * distr){
	computePijGam pi;
	pi._V.resize(distr->categories());
	for (int i=0; i < spVec.size(); ++i) {
		pi._V[i].fillPij(et,*spVec[i]);
	}
	
	suffStatGlobalGam ssc;
	computeUpAlg cup;
	cup.fillComputeUp(et,sc,pi,ssc);
	
	return getTreeLikelihoodUpIsFilledSelectionGam(et,sc,spVec,ssc,distr);
}


MDOUBLE likelihoodComputationSPvec::getTreeLikelihoodUpIsFilledSelectionGam(const tree& et,
						const sequenceContainer& sc,
						const vector<stochasticProcess*>& spVec,
						const suffStatGlobalGam& ssc,const distribution * distr){
	MDOUBLE res = 0.0;
	int k;
	for (k=0; k < sc.seqLen(); ++k) {
		MDOUBLE lnL = log(likelihoodComputationSPvec::getProbOfPosUpIsFilledSelectionGam(k,//pos,
			  et,
			  sc,
			  *spVec[0],
			  ssc[k],
			  distr)); 
		res += lnL;
	}
	return res;
}

MDOUBLE likelihoodComputationSPvec::getProbOfPosUpIsFilledSelectionGam(const int pos,const tree& et,
						const sequenceContainer& sc,
						const stochasticProcess& sp,
						const suffStatGlobalGamPos& cup,const distribution * distr){

	doubleRep tmp=0.0;
	for (int categor = 0; categor < distr->categories(); ++categor) {
		doubleRep veryTmp =0;
		for (int let =0; let < sc.alphabetSize(); ++let) {
			veryTmp+=cup.get(categor,et.getRoot()->id(),let) * sp.freq(let);
			
		}
		tmp += veryTmp*distr->ratesProb(categor);
	}
	if (!(tmp>0.0))
		errorMsg::reportError("Error in likelihoodComputationSPvec::getTreeLikelihoodFromUp2: negative likelihood");
	return convert(tmp);
}

MDOUBLE likelihoodComputationSPvec::getTreeLikelihoodFromUp2(const tree& et,
						const sequenceContainer& sc,
						const stochasticProcess& sp,
						const suffStatGlobalGam& cup,
						Vdouble& posLike, // fill this vector with each position likelihood but without the weights.
						const distribution * distr,
						const Vdouble * weights) {
	posLike.clear();
	MDOUBLE like = 0;
	//computing the likelihood from up:
	for (int pos = 0; pos < sc.seqLen(); ++pos) {
		doubleRep tmp=0;
		for (int categor = 0; categor < distr->categories(); ++categor) {
			doubleRep veryTmp =0;
			for (int let =0; let < sc.alphabetSize(); ++let) {
				veryTmp+=cup.get(pos,categor,et.getRoot()->id(),let) * sp.freq(let);
			}
			tmp += veryTmp*distr->ratesProb(categor);
		}
		if (!(tmp>0.0))
			errorMsg::reportError("Error in likelihoodComputationSPvec::getTreeLikelihoodFromUp2: negative likelihood");
		like += log(tmp) * (weights?(*weights)[pos]:1);
		posLike.push_back(convert(tmp));
	}
	return like;

}
