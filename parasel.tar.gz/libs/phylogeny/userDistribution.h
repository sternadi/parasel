// $Id: userDistribution.h 2812 2007-11-25 10:32:11Z itaymay $

 // version 2.00 
// last modified 21 Mar 2004
#ifndef ___USER_DIST
#define ___USER_DIST

#include "distribution.h"

/***********************************************************
 input from user: rates and probabilities
************************************************************/

class userDistribution : public distribution {

public:
	userDistribution(Vdouble rates, Vdouble probs): _rates(rates), _probs(probs) {verify_probs();}
	virtual const int categories() const { return _probs.size();}
	virtual void change_number_of_categories(int in_number_of_categories);
	virtual const MDOUBLE rates(const int i) const ;
	virtual const MDOUBLE ratesProb(const int i) const ;
	virtual userDistribution* clone() const { return new userDistribution(*this); }
 	virtual void setGlobalRate(const MDOUBLE x) {_globalRate = x;}
 	virtual MDOUBLE getGlobalRate() const{return _globalRate;}
	virtual const MDOUBLE getCumulativeProb(const MDOUBLE x) const 	;
	void resetProbs(Vdouble probs) {_probs=probs; verify_probs();}

	MDOUBLE _globalRate;
private:
	void verify_probs();

private:
	Vdouble _rates;
	Vdouble _probs;
};

#endif

