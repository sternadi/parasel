// $RCSfile$ $Revision: 950 $ $Date: 2006-10-19 14:12:34 +0200 (ה, 19 אוקטובר 2006) $

#include "likeDistSPvec.h"
#include "numRec.h"

likeDistSPvec::likeDistSPvec(const vector<stochasticProcess*>& spVec, const distribution *distr,
					   const MDOUBLE toll ,
					   const MDOUBLE maxPairwiseDistance) :  
_toll(toll),_maxPairwiseDistance(maxPairwiseDistance) {
	_distr = distr->clone();
	_spVec.resize(spVec.size());
	for (int i = 0; i < spVec.size(); ++i){
		if (spVec[i])
			_spVec[i] = spVec[i]->clone();
	}
}

likeDistSPvec::likeDistSPvec (const likeDistSPvec& other):  
_toll(other._toll),_maxPairwiseDistance(other._maxPairwiseDistance) {
	if (other._distr)
		_distr = other._distr->clone();
	_spVec.resize(other._spVec.size());
	for (int i = 0; i < other._spVec.size(); ++i){
		if (other._spVec[i])
			_spVec[i] = other._spVec[i]->clone();
	}
}

likeDistSPvec::~likeDistSPvec(){
	if (_distr)
		delete _distr;
	for (int i = 0; i< _spVec.size(); ++i){
		if (_spVec[i]) delete _spVec[i];
	}
}

const MDOUBLE likeDistSPvec::giveDistance(	const countTableComponentGam& ctc,
										   MDOUBLE& resQ,
										   const MDOUBLE initialGuess) const {
	return giveDistanceBrent(ctc,resQ,initialGuess);
}

const MDOUBLE likeDistSPvec::giveDistanceBrent(	const countTableComponentGam& ctc,
										   MDOUBLE& resL,
										   const MDOUBLE initialGuess) const {
	const MDOUBLE ax=0,bx=initialGuess,cx=_maxPairwiseDistance,tol=_toll;
	MDOUBLE dist=-1.0;
	resL = -dbrent(ax,bx,cx,
		  C_evalLikeDistSPvec(ctc,_spVec),
		  C_evalLikeDist_d_SPvec(ctc,_spVec,_distr),
		  tol,
		  &dist);
	return dist;
}


C_evalLikeDistSPvec::C_evalLikeDistSPvec(const countTableComponentGam& ctc, const vector<stochasticProcess*>& spVec):
_ctc(ctc)
{
	_spVec.resize(spVec.size());
	for (int i = 0; i < spVec.size(); ++i){
		if (spVec[i])
			_spVec[i] = spVec[i]->clone();
	}
}

C_evalLikeDistSPvec::~C_evalLikeDistSPvec(){
	for (int i = 0; i< _spVec.size(); ++i){
		if (_spVec[i]) delete _spVec[i];
	}
}

C_evalLikeDist_d_SPvec::C_evalLikeDist_d_SPvec(const countTableComponentGam& ctc, 
											   const vector<stochasticProcess*>& spVec,
											   const distribution *distr)    
											   : _ctc(ctc) {
	
	_spVec.resize(spVec.size());
	for (int i = 0; i < spVec.size(); ++i){
		if (spVec[i])
			_spVec[i] = spVec[i]->clone();
	}
	if (distr)
		_distr = distr->clone();
}

C_evalLikeDist_d_SPvec::~C_evalLikeDist_d_SPvec(){
    if (_distr)
	delete _distr;
    
	for (int i = 0; i< _spVec.size(); ++i){
		if (_spVec[i]) delete _spVec[i];
	}
}


MDOUBLE C_evalLikeDist_d_SPvec::operator() (MDOUBLE dist){
		MDOUBLE	sumDL = 0.0;
		for (int alph1=0; alph1 <  _ctc.alphabetSize(); ++alph1){
			for (int alph2=0; alph2 <  _ctc.alphabetSize(); ++alph2){
				for (int categor = 0; categor<_spVec.size(); ++categor) {
					MDOUBLE distributionFactor = _distr->rates(categor);
					MDOUBLE pij= _spVec[categor]->Pij_t(alph1,alph2,dist);
					MDOUBLE dpij = _spVec[categor]->dPij_dt(alph1,alph2,dist);
					sumDL+= _ctc.getCounts(alph1,alph2,categor)*dpij //*_sp.ratesProb(rateCategor) : removed CODE_RED
									*distributionFactor/pij;
				}
			}
		}
		return -sumDL;
}
					   
