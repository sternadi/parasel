// $Id: fromCountTableComponentToDistanceSPvec.h 950 2006-10-19 12:12:34Z eyalprivman $

#ifndef ___FROM_COUNT_TABLE_COMPONENT_TO_DISTANCE_SPVEC
#define ___FROM_COUNT_TABLE_COMPONENT_TO_DISTANCE_SPVEC

#include "definitions.h"
#include "countTableComponent.h"
#include "stochasticProcess.h"

static const MDOUBLE startingGuessForTreeBrLen = 0.029;

class fromCountTableComponentToDistanceSPvec {

public:
	explicit fromCountTableComponentToDistanceSPvec(
		const countTableComponentGam& ctc,
		const vector<stochasticProcess*> &spVec,
		const distribution *distr,
		const MDOUBLE toll,
		const MDOUBLE brLenIntialGuess);// =startingGuessForTreeBrLen
	fromCountTableComponentToDistanceSPvec (const fromCountTableComponentToDistanceSPvec& other);

	virtual ~fromCountTableComponentToDistanceSPvec();

	void computeDistance();// return the likelihood
	MDOUBLE getDistance() { return _distance;} // return the distance.
	MDOUBLE getLikeDistance() { return _likeDistance;} // return the distance.
private:
	vector<stochasticProcess*>  _spVec;
	const countTableComponentGam& _ctc;
	distribution *_distr;
	MDOUBLE _toll;
	MDOUBLE _distance;
	MDOUBLE _likeDistance;
	int alphabetSize() {return _ctc.alphabetSize();}
};

#endif

