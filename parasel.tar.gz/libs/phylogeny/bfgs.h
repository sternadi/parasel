/*
  mod by thorfinn@binf.ku.dk 7 nov 2011.

  The code looks like fortran 2 c translated program of v 2.1
  http://users.eecs.northwestern.edu/~nocedal/lbfgsb.html

  1) Fixed a bug concerning non-consistency in the optimized parameters (accecing noninitialized values)
  2) Is now thread safe. (removed local static variables)
  3) Added a "data" paramater to the findmax_bfgs, such that global variables can be avoided
  4) modified code such that it is c and c++ compilable.
 */

//these three parameters affect precision of optimization.
//m is not recommended to be higher than 20
//decreasing factr, pgtol will increase precision
//factr is the multiple of machine precision that result will be
//pgtol is size of gradient on exit
#define MVAL 10
#define FACTR 1.0e6 // default was 1.0e6
#define PGTOL 1.0e-3 // default was 1.0e-3

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "logFile.h"
using namespace std;

typedef int logical;//ADI

//nbd is a vector of integers of dimension numpars.
//nbd[i]=0 if there are no bounds for parameter i, 
//      =1 if there are only lower bounds
//      =2 if there are both lower/upper bounds
//      =3 if there is only upper bound                
//or send nbd=NULL is equivalent to nbd=2 for all parameters
//
//noisy=0 => no output, noisy=1 => one line of output, noisy < 99 some output,
//noisy>=100 probably too much
//
//dfun is derivative function or send NULL to use numerical derivative
//(getgradient function)

/*
  numpars = dimension of optimization
  invec   = Must have length numpars, will be used at startpoint for optimization. 
            Contains the optimized parameters
  dats    = This can contain a pointer to a generic structure which contains need data
            Can be NULL, if no "global" variables are needed
  fun     = function to optimize
  dfun    = derivative function
  lowbound= lower bounds
  upbound = upper bounds
  nbd,noisy   = see above
  
 */

void my_strcpy(char *s1, char *s2);


template <typename regF>
void Yanggradient (int n, const double x[], double f0,
		   double g[],const void*dats, regF fun,
		   double space[],
		   const double* lowbound, const double* upbound){

  int i,j;
  double *x0=space, *x1=space+n, eh0, eh01, eh;
  eh0=eh01=1.e-8;
  //LOG(5,<<"in Yanggradient"<<endl);
  for (i=0;i<n;i++)  {
	  for (j=0;j<n;j++)
		  x0[j]=x1[j]=x[j];
	  eh=pow(eh01*(fabs(x[i])+1), 0.67);
	  x0[i]-=eh; x1[i]+=eh;
	  if (x0[i]<lowbound[i])
		  {x1[i]+=eh; g[i] = (fun(x1,dats)-f0)/(eh*2.0);}
	  else if (x1[i]>upbound[i])
		  {x0[i]-=eh; g[i] = (f0-fun(x0,dats))/(eh*2.0);}
	  else {
		  double val1=fun(x1,dats);
		  double val2=fun(x0,dats);
		  //g[i] = (fun(x1,dats) - fun(x0,dats))/(eh*2.0);
		g[i] = (val1 - val2)/(eh*2.0);
		  //LOG(5,<<"i="<<i<<" g[i]="<<g[i]<<" fun(x1)="<<val1<<" fun(x2)="<<val2<<" eh="<<eh<<endl)

	  }
  }
}

template <typename regF>
/*void getgradient(int npar, const double invec[],double outvec[],
		 const void*dats,double(*func)(const double [],const void*),
		 const double* lowbound, const double* upbound);ADI*/
void getgradient(int npar, const double invec[],
		 double outvec[],const void*dats, regF func,
		 const double* lowbound, const double* upbound){

  double f0;
  int i;
  double *space =(double *)calloc((2*npar+10),sizeof(double));
 f0 = func(invec,dats);
  Yanggradient(npar, invec, f0, outvec,dats, func, space, lowbound, upbound);

 checkbounds:
  for (i=0; i<npar; i++) {
    if (invec[i] <= lowbound[i] && outvec[i] > 0.0)
      outvec[i] = 0.0;
    if (invec[i] >=upbound[i] && outvec[i] < 0.0)
      outvec[i] = 0.0;
  }
 free(space);
}

template <typename regF>
/*double findmax_bfgs(int numpars, double *invec,const void*dats, double (*fun)(const double x[],const void*),
		    void (*dfun)(const double x[], double y[]),
		    double *lowbound, double *upbound,
		    int *nbd, int noisy);ADI (moved function ot header*/
double findmax_bfgs(int numpars, double *invec,const void*dats, regF fun,
		    void (*dfun)(const double x[], double y[]),
		    double *lowbound, double *upbound,
		    int *nbd, int noisy){
	int i, m, isave[44], *iwa;
  double *grad, *wa, factr, pgtol, dsave[29], like;
  char task[60], csave[60];
  int setulb_(int *n, int *m, double *x, double *l, double *u,
			     int *nbd, double *f, double *g, double *factr,
			     double *pgtol, double *wa, int *iwa,
			     char *task, int *iprint, char *csave, int *lsave,
	      int *isave, double *dsave);
  //    int setulb_();
  void my_strcpy(char *s1, char *s2);
  logical lsave[4];

  m=MVAL;
  factr = FACTR;
  pgtol = PGTOL;

  //important to zero initialize arrays below
  grad =(double *) calloc(numpars,sizeof(double));
  wa =(double *) calloc(((2*m+4)*numpars + 12*m*m + 12*m),sizeof(double));
  iwa =(int *) calloc(3*numpars,sizeof(int));
  my_strcpy(task, "START");
  for (i=5; i<60; i++) task[i]=' ';
  //like = (*fun)(invec,dats);//ADI
  like=fun(invec,dats);//ADI
  if(dfun!=NULL)
    dfun(invec, grad);
  else
    getgradient(numpars,invec,grad,dats,fun,lowbound,upbound);
  cout<<"finished getting gradient"<<endl;//debug

  while (1) {

    setulb_(&numpars, &m, invec, lowbound, upbound, nbd, &like,grad, &factr, &pgtol, wa, iwa, task, &noisy, csave, lsave,isave, dsave);

    if (task[0]=='F' && task[1]=='G') {
      //printf("\t");
    	LOG(5,<<"\t");
      like = fun(invec,dats);
      if(dfun!=NULL)
	dfun(invec, grad);
      else
	getgradient(numpars,invec,grad,dats,fun,lowbound,upbound);
      //if (noisy > 1) printf("like=%f\n", like);
      if (noisy > 1) LOG(5,<<"like="<<like<<endl);
      continue;
    }
    else if (strncmp(task, "NEW_X", 5)==0) {
      //      if (noisy > 1) printf("\n");
      continue;
    }
    else break;
  }
  if (noisy > 1) printf("\n");

  free(wa);
  free(iwa);
  free(grad);
  return -like;
}



