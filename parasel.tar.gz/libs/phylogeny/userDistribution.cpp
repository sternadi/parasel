// $Id: userDistribution.cpp 2711 2007-11-19 14:49:54Z itaymay $

#include "userDistribution.h"
#include "someUtil.h"
#include "errorMsg.h"


void userDistribution::change_number_of_categories(int in_number_of_categories)
{
	if (in_number_of_categories != _rates.size())
		errorMsg::reportError("error in userDistribution::change_number_of_categories() - number of categories is not as previous");
}


void userDistribution::verify_probs()
{
	MDOUBLE epsilon = 0.000001;
	MDOUBLE sum = 0.0;
	for (int i=0; i<_probs.size(); ++i)
		sum+=_probs[i];

	if (!DEQUAL(sum,1.0,epsilon))
		errorMsg::reportError("error in userDistribution::verify_probs() - sum of probs is not 1");
	if (_rates.size()!=_probs.size() )
		errorMsg::reportError("error in userDistribution::verify_probs() - size of _probs is not equal to size of _rates");


}


const MDOUBLE userDistribution::rates(const int i) const {
	if (i >= _rates.size())
		errorMsg::reportError("error in userDistribution::rates() - requested rate category which does not exist");
	return _rates[i];

}

const MDOUBLE userDistribution::ratesProb(const int i) const {
	if (i >= _probs.size())
		errorMsg::reportError("error in userDistribution::rates() - requested rate probability which does not exist");
	return _probs[i];
}


const MDOUBLE userDistribution::getCumulativeProb(const MDOUBLE x) const {
	errorMsg::reportError("error in userDistribution::getCumulativeProb() - NOT IMPLEMETNED");
	return -1.0;
}
